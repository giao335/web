# 环境变量参考

## 必需的环境变量

### 数据库配置
```
DATABASE_URL=mysql://user:password@host:3306/database_name
```
- **说明**: MySQL 数据库连接字符串
- **格式**: `mysql://username:password@hostname:port/database`
- **示例**: `mysql://wugu:password123@db.aliyuncs.com:3306/wugu_downloads`

### 应用配置
```
NODE_ENV=production
PORT=3000
```
- **NODE_ENV**: 运行环境（development/production）
- **PORT**: 应用监听端口

## 可选的环境变量

### 应用信息
```
VITE_APP_TITLE=五谷杂粮下载中心
VITE_APP_LOGO=https://your-cdn.com/logo.png
VITE_APP_ID=your_app_id
```

### OAuth 认证
```
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
JWT_SECRET=your_jwt_secret_key_here
```

### 所有者信息
```
OWNER_NAME=Your Name
OWNER_OPEN_ID=your_open_id
```

### S3 存储（用于文件上传）
```
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_S3_BUCKET=your_bucket_name
```

### Stripe 支付
```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

### 分析
```
VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
VITE_ANALYTICS_WEBSITE_ID=your_website_id
```

### 内置 API
```
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=your_frontend_api_key
```

## 在阿里云上配置环境变量

### 方法 1: 使用 .env.local 文件

```bash
# 在项目根目录创建 .env.local
cat > .env.local << EOF
DATABASE_URL=mysql://wugu:password@your-rds.rds.aliyuncs.com:3306/wugu_downloads
NODE_ENV=production
PORT=3000
VITE_APP_TITLE=五谷杂粮下载中心
JWT_SECRET=your_secret_key
EOF
```

### 方法 2: 使用系统环境变量

```bash
export DATABASE_URL="mysql://wugu:password@your-rds.rds.aliyuncs.com:3306/wugu_downloads"
export NODE_ENV="production"
export VITE_APP_TITLE="五谷杂粮下载中心"
```

### 方法 3: 使用 Docker 环境变量

在 `docker-compose.yml` 中配置：

```yaml
environment:
  DATABASE_URL: mysql://wugu:password@mysql:3306/wugu_downloads
  NODE_ENV: production
  VITE_APP_TITLE: 五谷杂粮下载中心
```

## 生成安全的 JWT_SECRET

```bash
# 使用 OpenSSL
openssl rand -base64 32

# 或使用 Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

## 获取阿里云 RDS 连接信息

1. 登录阿里云控制台
2. 进入 RDS 实例详情
3. 查看"基本信息"中的：
   - **内网地址**: 用于 ECS 内部连接
   - **公网地址**: 用于外部连接（需要开启）
   - **端口**: 通常为 3306
   - **数据库名**: 创建的数据库名
   - **主账号**: 数据库用户名
   - **密码**: 数据库密码

## 安全建议

1. **不要在代码中硬编码敏感信息**
2. **使用强密码**（至少 16 个字符，包含大小写字母、数字和特殊符号）
3. **定期轮换密钥**
4. **使用 .gitignore 排除 .env.local 文件**
5. **在生产环境使用 AWS Secrets Manager 或阿里云密钥管理服务**

## 故障排查

### 数据库连接失败
- 检查 DATABASE_URL 格式是否正确
- 确认 RDS 实例状态为"运行中"
- 检查安全组规则是否允许连接
- 验证用户名和密码是否正确

### 应用无法启动
- 检查所有必需的环境变量是否已设置
- 查看应用日志获取详细错误信息
- 确认 PORT 未被其他进程占用

### OAuth 认证失败
- 验证 OAUTH_SERVER_URL 是否可访问
- 检查 JWT_SECRET 是否正确设置
- 确认 VITE_APP_ID 与 OAuth 应用配置一致
