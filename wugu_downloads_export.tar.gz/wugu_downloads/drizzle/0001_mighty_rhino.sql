CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`icon` varchar(50),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `downloadStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`softwareId` int NOT NULL,
	`userId` int,
	`downloadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `downloadStats_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `software` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`version` varchar(50) NOT NULL,
	`downloadUrl` varchar(2048) NOT NULL,
	`fileSize` varchar(50),
	`downloadCount` int NOT NULL DEFAULT 0,
	`releaseDate` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `software_id` PRIMARY KEY(`id`)
);
