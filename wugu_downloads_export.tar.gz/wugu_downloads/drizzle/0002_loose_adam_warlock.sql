CREATE TABLE `changelogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`softwareId` int NOT NULL,
	`version` varchar(50) NOT NULL,
	`releaseDate` timestamp NOT NULL DEFAULT (now()),
	`title` varchar(255) NOT NULL,
	`description` text,
	`features` text,
	`bugFixes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `changelogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`softwareId` int NOT NULL,
	`userId` int NOT NULL,
	`rating` int NOT NULL,
	`title` varchar(255),
	`comment` text,
	`helpful` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
