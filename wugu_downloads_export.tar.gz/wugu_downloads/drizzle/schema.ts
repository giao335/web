import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, unique, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Software table for managing downloadable software
export const software = mysqlTable("software", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }).notNull(), // e.g., "Windows", "Linux", "macOS", "Android", "iOS", "Web"
  appType: varchar("appType", { length: 100 }).notNull(), // e.g., "Game", "Productivity", "Social", "Development", "Utility", "Media"
  version: varchar("version", { length: 50 }).notNull(),
  downloadUrl: varchar("downloadUrl", { length: 2048 }).notNull(),
  fileSize: varchar("fileSize", { length: 50 }), // e.g., "50MB", "1.2GB"
  downloadCount: int("downloadCount").default(0).notNull(),
  releaseDate: timestamp("releaseDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Software = typeof software.$inferSelect;
export type InsertSoftware = typeof software.$inferInsert;

// Download statistics table for tracking user downloads
export const downloadStats = mysqlTable("downloadStats", {
  id: int("id").autoincrement().primaryKey(),
  softwareId: int("softwareId").notNull(),
  userId: int("userId"), // nullable for anonymous downloads
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
});

export type DownloadStats = typeof downloadStats.$inferSelect;
export type InsertDownloadStats = typeof downloadStats.$inferInsert;

// Software categories table
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  icon: varchar("icon", { length: 50 }), // lucide-react icon name
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

// Software reviews table for user ratings and comments
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  softwareId: int("softwareId").notNull(),
  userId: int("userId").notNull(),
  rating: int("rating").notNull(), // 1-5 stars
  title: varchar("title", { length: 255 }),
  comment: text("comment"),
  helpful: int("helpful").default(0).notNull(), // count of helpful votes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

// Software changelog table for version updates
export const changelogs = mysqlTable("changelogs", {
  id: int("id").autoincrement().primaryKey(),
  softwareId: int("softwareId").notNull(),
  version: varchar("version", { length: 50 }).notNull(),
  releaseDate: timestamp("releaseDate").defaultNow().notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  features: text("features"), // JSON array of new features
  bugFixes: text("bugFixes"), // JSON array of bug fixes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Changelog = typeof changelogs.$inferSelect;
export type InsertChangelog = typeof changelogs.$inferInsert;

// User download history table for tracking user's download history
export const downloadHistory = mysqlTable("downloadHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  softwareId: int("softwareId").notNull(),
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  uniqUserSoftware: unique("unique_user_software").on(table.userId, table.softwareId),
}));

export type DownloadHistory = typeof downloadHistory.$inferSelect;
export type InsertDownloadHistory = typeof downloadHistory.$inferInsert;

// User favorites/bookmarks table for saving favorite software
export const favorites = mysqlTable("favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  softwareId: int("softwareId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  uniqUserSoftware: unique("unique_fav_user_software").on(table.userId, table.softwareId),
}));

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = typeof favorites.$inferInsert;

// User preferences table for storing user settings like theme preference
export const userPreferences = mysqlTable("userPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  theme: varchar("theme", { length: 20 }).default("light").notNull(), // "light" or "dark"
  language: varchar("language", { length: 20 }).default("zh").notNull(), // "zh" or "en"
  notificationsEnabled: int("notificationsEnabled").default(1).notNull(), // 0 or 1 (boolean)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = typeof userPreferences.$inferInsert;