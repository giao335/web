import { describe, expect, it, beforeAll } from "vitest";
import { getSoftware, getTopSoftware, getCategories } from "./software";

describe("Software API", () => {
  describe("getSoftware", () => {
    it("should return all software when no category is provided", async () => {
      const software = await getSoftware();
      expect(Array.isArray(software)).toBe(true);
      expect(software.length).toBeGreaterThan(0);
    });

    it("should filter software by category", async () => {
      const windowsSoftware = await getSoftware("Windows");
      expect(Array.isArray(windowsSoftware)).toBe(true);
      if (windowsSoftware.length > 0) {
        expect(windowsSoftware[0].category).toBe("Windows");
      }
    });

    it("should return empty array for non-existent category", async () => {
      const software = await getSoftware("NonExistent");
      expect(Array.isArray(software)).toBe(true);
      expect(software.length).toBe(0);
    });
  });

  describe("getTopSoftware", () => {
    it("should return top software sorted by download count", async () => {
      const topSoftware = await getTopSoftware(10);
      expect(Array.isArray(topSoftware)).toBe(true);
      
      // Check if sorted by download count (descending)
      for (let i = 1; i < topSoftware.length; i++) {
        expect(topSoftware[i - 1].downloadCount).toBeGreaterThanOrEqual(
          topSoftware[i].downloadCount
        );
      }
    });

    it("should respect the limit parameter", async () => {
      const topSoftware = await getTopSoftware(5);
      expect(topSoftware.length).toBeLessThanOrEqual(5);
    });

    it("should return default limit of 10 when not specified", async () => {
      const topSoftware = await getTopSoftware();
      expect(topSoftware.length).toBeLessThanOrEqual(10);
    });
  });

  describe("getCategories", () => {
    it("should return all categories", async () => {
      const categories = await getCategories();
      expect(Array.isArray(categories)).toBe(true);
      expect(categories.length).toBeGreaterThan(0);
    });

    it("should have required category fields", async () => {
      const categories = await getCategories();
      if (categories.length > 0) {
        const category = categories[0];
        expect(category).toHaveProperty("id");
        expect(category).toHaveProperty("name");
        expect(typeof category.name).toBe("string");
      }
    });
  });
});
