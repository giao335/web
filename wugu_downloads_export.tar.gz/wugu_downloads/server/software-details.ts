import { eq, desc } from "drizzle-orm";
import { reviews, changelogs } from "../drizzle/schema";
import { getDb } from "./db";
import type { InsertReview, InsertChangelog } from "../drizzle/schema";

/**
 * Get all reviews for a software
 */
export async function getReviews(softwareId: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.softwareId, softwareId))
      .orderBy(desc(reviews.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get reviews:", error);
    return [];
  }
}

/**
 * Get average rating for a software
 */
export async function getAverageRating(softwareId: number) {
  const db = await getDb();
  if (!db) return 0;

  try {
    const result = await db
      .select()
      .from(reviews)
      .where(eq(reviews.softwareId, softwareId));

    if (result.length === 0) return 0;
    const sum = result.reduce((acc, r) => acc + r.rating, 0);
    return Math.round((sum / result.length) * 10) / 10;
  } catch (error) {
    console.error("[Database] Failed to get average rating:", error);
    return 0;
  }
}

/**
 * Get rating distribution for a software
 */
export async function getRatingDistribution(softwareId: number) {
  const db = await getDb();
  if (!db) return { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };

  try {
    const result = await db
      .select()
      .from(reviews)
      .where(eq(reviews.softwareId, softwareId));

    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    result.forEach((r) => {
      if (r.rating >= 1 && r.rating <= 5) {
        distribution[r.rating as keyof typeof distribution]++;
      }
    });
    return distribution;
  } catch (error) {
    console.error("[Database] Failed to get rating distribution:", error);
    return { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  }
}

/**
 * Add a review for a software
 */
export async function addReview(review: InsertReview) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.insert(reviews).values(review);
    return result;
  } catch (error) {
    console.error("[Database] Failed to add review:", error);
    return null;
  }
}

/**
 * Get changelogs for a software
 */
export async function getChangelogs(softwareId: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(changelogs)
      .where(eq(changelogs.softwareId, softwareId))
      .orderBy(desc(changelogs.releaseDate));
  } catch (error) {
    console.error("[Database] Failed to get changelogs:", error);
    return [];
  }
}

/**
 * Add a changelog for a software
 */
export async function addChangelog(changelog: InsertChangelog) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db.insert(changelogs).values(changelog);
    return result;
  } catch (error) {
    console.error("[Database] Failed to add changelog:", error);
    return null;
  }
}
