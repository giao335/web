import { eq, and, desc } from "drizzle-orm";
import { downloadHistory, favorites, userPreferences, software } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Add a software to user's download history
 */
export async function addDownloadHistory(userId: number, softwareId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db
      .insert(downloadHistory)
      .values({
        userId,
        softwareId,
        downloadedAt: new Date(),
        createdAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          downloadedAt: new Date(),
        },
      });
  } catch (error) {
    console.error("[Database] Failed to add download history:", error);
    throw error;
  }
}

/**
 * Get user's download history
 */
export async function getDownloadHistory(userId: number, limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const result = await db
      .select({
        id: downloadHistory.id,
        softwareId: downloadHistory.softwareId,
        downloadedAt: downloadHistory.downloadedAt,
        software: {
          id: software.id,
          name: software.name,
          description: software.description,
          version: software.version,
          fileSize: software.fileSize,
          downloadCount: software.downloadCount,
        },
      })
      .from(downloadHistory)
      .innerJoin(software, eq(downloadHistory.softwareId, software.id))
      .where(eq(downloadHistory.userId, userId))
      .orderBy(desc(downloadHistory.downloadedAt))
      .limit(limit)
      .offset(offset);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get download history:", error);
    throw error;
  }
}

/**
 * Add a software to user's favorites
 */
export async function addFavorite(userId: number, softwareId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db
      .insert(favorites)
      .values({
        userId,
        softwareId,
        createdAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          createdAt: new Date(),
        },
      });
  } catch (error) {
    console.error("[Database] Failed to add favorite:", error);
    throw error;
  }
}

/**
 * Remove a software from user's favorites
 */
export async function removeFavorite(userId: number, softwareId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db
      .delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.softwareId, softwareId)));
  } catch (error) {
    console.error("[Database] Failed to remove favorite:", error);
    throw error;
  }
}

/**
 * Get user's favorite software
 */
export async function getFavorites(userId: number, limit: number = 20, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const result = await db
      .select({
        id: favorites.id,
        softwareId: favorites.softwareId,
        createdAt: favorites.createdAt,
        software: {
          id: software.id,
          name: software.name,
          description: software.description,
          version: software.version,
          fileSize: software.fileSize,
          downloadCount: software.downloadCount,
        },
      })
      .from(favorites)
      .innerJoin(software, eq(favorites.softwareId, software.id))
      .where(eq(favorites.userId, userId))
      .orderBy(desc(favorites.createdAt))
      .limit(limit)
      .offset(offset);

    return result;
  } catch (error) {
    console.error("[Database] Failed to get favorites:", error);
    throw error;
  }
}

/**
 * Check if a software is in user's favorites
 */
export async function isFavorite(userId: number, softwareId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const result = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.softwareId, softwareId)))
      .limit(1);

    return result.length > 0;
  } catch (error) {
    console.error("[Database] Failed to check favorite:", error);
    throw error;
  }
}

/**
 * Get user's preferences
 */
export async function getUserPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const result = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get user preferences:", error);
    throw error;
  }
}

/**
 * Update user's preferences
 */
export async function updateUserPreferences(
  userId: number,
  updates: {
    theme?: string;
    language?: string;
    notificationsEnabled?: number;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const existing = await getUserPreferences(userId);

    if (existing) {
      await db
        .update(userPreferences)
        .set({
          ...updates,
          updatedAt: new Date(),
        })
        .where(eq(userPreferences.userId, userId));
    } else {
      await db
        .insert(userPreferences)
        .values({
          userId,
          theme: updates.theme || "light",
          language: updates.language || "zh",
          notificationsEnabled: updates.notificationsEnabled ?? 1,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
    }
  } catch (error) {
    console.error("[Database] Failed to update user preferences:", error);
    throw error;
  }
}
