import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getSoftware, getTopSoftware, getCategories, recordDownload, getSoftwareById, filterSoftware, FilterOptions } from "./software";
import { getReviews, getAverageRating, getRatingDistribution, addReview, getChangelogs, addChangelog } from "./software-details";
import { addDownloadHistory, getDownloadHistory, addFavorite, removeFavorite, getFavorites, isFavorite, getUserPreferences, updateUserPreferences } from "./user-features";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  software: router({
    // Get all software, optionally filtered by category
    list: publicProcedure
      .input(z.object({ category: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return getSoftware(input?.category);
      }),

    // Get top downloaded software for rankings
    top: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(async ({ input }) => {
        return getTopSoftware(input?.limit || 10);
      }),

    // Get all categories
    categories: publicProcedure.query(async () => {
      return getCategories();
    }),

    // Get a specific software by ID
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getSoftwareById(input.id);
      }),

    // Record a download and increment counter
    recordDownload: publicProcedure
      .input(z.object({ softwareId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const success = await recordDownload(input.softwareId, ctx.user?.id);
        return { success };
      }),

    // Filter software by multiple dimensions
    filter: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        minFileSize: z.number().optional(),
        maxFileSize: z.number().optional(),
        minRating: z.number().optional(),
        maxRating: z.number().optional(),
        minDownloads: z.number().optional(),
        maxDownloads: z.number().optional(),
        sortBy: z.enum(['downloads', 'rating', 'fileSize', 'name']).optional(),
        sortOrder: z.enum(['asc', 'desc']).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const options: FilterOptions = {
          category: input.category,
          minFileSize: input.minFileSize,
          maxFileSize: input.maxFileSize,
          minRating: input.minRating,
          maxRating: input.maxRating,
          minDownloads: input.minDownloads,
          maxDownloads: input.maxDownloads,
          sortBy: input.sortBy,
          sortOrder: input.sortOrder,
          limit: input.limit,
          offset: input.offset,
        };
        return filterSoftware(options);
      }),
  }),

  user: router({
    // Get user's download history
    downloadHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }).optional())
      .query(async ({ input, ctx }) => {
        return getDownloadHistory(ctx.user!.id, input?.limit || 20, input?.offset || 0);
      }),

    // Get user's favorite software
    favorites: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }).optional())
      .query(async ({ input, ctx }) => {
        return getFavorites(ctx.user!.id, input?.limit || 20, input?.offset || 0);
      }),

    // Add a software to favorites
    addFavorite: protectedProcedure
      .input(z.object({ softwareId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await addFavorite(ctx.user!.id, input.softwareId);
        return { success: true };
      }),

    // Remove a software from favorites
    removeFavorite: protectedProcedure
      .input(z.object({ softwareId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await removeFavorite(ctx.user!.id, input.softwareId);
        return { success: true };
      }),

    // Check if a software is in favorites
    isFavorite: protectedProcedure
      .input(z.object({ softwareId: z.number() }))
      .query(async ({ input, ctx }) => {
        const result = await isFavorite(ctx.user!.id, input.softwareId);
        return { isFavorite: result };
      }),

    // Get user's preferences
    getPreferences: protectedProcedure
      .query(async ({ ctx }) => {
        return getUserPreferences(ctx.user!.id);
      }),

    // Update user's preferences
    updatePreferences: protectedProcedure
      .input(z.object({
        theme: z.enum(['light', 'dark']).optional(),
        language: z.enum(['zh', 'en']).optional(),
        notificationsEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await updateUserPreferences(ctx.user!.id, {
          theme: input.theme,
          language: input.language,
          notificationsEnabled: input.notificationsEnabled ? 1 : 0,
        });
        return { success: true };
      }),
  }),

  details: router({
    // Get reviews for a software
    getReviews: publicProcedure
      .input(z.object({ softwareId: z.number() }))
      .query(async ({ input }) => {
        return getReviews(input.softwareId);
      }),

    // Get average rating for a software
    getAverageRating: publicProcedure
      .input(z.object({ softwareId: z.number() }))
      .query(async ({ input }) => {
        const average = await getAverageRating(input.softwareId);
        const distribution = await getRatingDistribution(input.softwareId);
        return { average, distribution };
      }),

    // Add a review for a software
    addReview: protectedProcedure
      .input(z.object({
        softwareId: z.number(),
        rating: z.number().min(1).max(5),
        title: z.string().optional(),
        comment: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await addReview({
          softwareId: input.softwareId,
          userId: ctx.user!.id,
          rating: input.rating,
          title: input.title,
          comment: input.comment,
        });
        return { success: !!result };
      }),

    // Get changelogs for a software
    getChangelogs: publicProcedure
      .input(z.object({ softwareId: z.number() }))
      .query(async ({ input }) => {
        return getChangelogs(input.softwareId);
      }),

    // Add a changelog for a software (admin only)
    addChangelog: protectedProcedure
      .input(z.object({
        softwareId: z.number(),
        version: z.string(),
        title: z.string(),
        description: z.string().optional(),
        features: z.string().optional(),
        bugFixes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Only admin can add changelogs
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admin can add changelogs");
        }
        const result = await addChangelog({
          softwareId: input.softwareId,
          version: input.version,
          title: input.title,
          description: input.description,
          features: input.features,
          bugFixes: input.bugFixes,
        });
        return { success: !!result };
      }),
  }),
});

export type AppRouter = typeof appRouter;
