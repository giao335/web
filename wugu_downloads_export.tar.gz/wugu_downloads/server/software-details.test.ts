import { describe, expect, it } from "vitest";
import { getReviews, getAverageRating, getRatingDistribution, getChangelogs } from "./software-details";

describe("Software Details API", () => {
  describe("getReviews", () => {
    it("should return reviews for a software", async () => {
      const reviews = await getReviews(1);
      expect(Array.isArray(reviews)).toBe(true);
    });

    it("should return empty array for non-existent software", async () => {
      const reviews = await getReviews(99999);
      expect(Array.isArray(reviews)).toBe(true);
      expect(reviews.length).toBe(0);
    });
  });

  describe("getAverageRating", () => {
    it("should return average rating for a software", async () => {
      const average = await getAverageRating(1);
      expect(typeof average).toBe("number");
      expect(average).toBeGreaterThanOrEqual(0);
      expect(average).toBeLessThanOrEqual(5);
    });

    it("should return 0 for software with no reviews", async () => {
      const average = await getAverageRating(99999);
      expect(average).toBe(0);
    });
  });

  describe("getRatingDistribution", () => {
    it("should return rating distribution for a software", async () => {
      const distribution = await getRatingDistribution(1);
      expect(distribution).toHaveProperty("5");
      expect(distribution).toHaveProperty("4");
      expect(distribution).toHaveProperty("3");
      expect(distribution).toHaveProperty("2");
      expect(distribution).toHaveProperty("1");
    });

    it("should have non-negative counts", async () => {
      const distribution = await getRatingDistribution(1);
      Object.values(distribution).forEach((count) => {
        expect(count).toBeGreaterThanOrEqual(0);
      });
    });
  });

  describe("getChangelogs", () => {
    it("should return changelogs for a software", async () => {
      const changelogs = await getChangelogs(1);
      expect(Array.isArray(changelogs)).toBe(true);
    });

    it("should return empty array for non-existent software", async () => {
      const changelogs = await getChangelogs(99999);
      expect(Array.isArray(changelogs)).toBe(true);
      expect(changelogs.length).toBe(0);
    });

    it("should have required changelog fields", async () => {
      const changelogs = await getChangelogs(1);
      if (changelogs.length > 0) {
        const changelog = changelogs[0];
        expect(changelog).toHaveProperty("id");
        expect(changelog).toHaveProperty("version");
        expect(changelog).toHaveProperty("title");
        expect(changelog).toHaveProperty("releaseDate");
      }
    });
  });
});
