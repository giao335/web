import { describe, expect, it, beforeAll } from "vitest";
import { filterSoftware, FilterOptions } from "./software";

describe("filterSoftware", () => {
  it("should return empty array when no filters applied", async () => {
    const result = await filterSoftware({});
    expect(Array.isArray(result)).toBe(true);
  });

  it("should filter by category", async () => {
    const result = await filterSoftware({ category: "Windows" });
    expect(Array.isArray(result)).toBe(true);
    result.forEach((item) => {
      expect(item.category).toBe("Windows");
    });
  });

  it("should filter by minimum download count", async () => {
    const result = await filterSoftware({ minDownloads: 1000 });
    expect(Array.isArray(result)).toBe(true);
    result.forEach((item) => {
      expect(item.downloadCount).toBeGreaterThanOrEqual(1000);
    });
  });

  it("should filter by maximum download count", async () => {
    const result = await filterSoftware({ maxDownloads: 5000 });
    expect(Array.isArray(result)).toBe(true);
    result.forEach((item) => {
      expect(item.downloadCount).toBeLessThanOrEqual(5000);
    });
  });

  it("should filter by file size range", async () => {
    const result = await filterSoftware({
      minFileSize: 50,
      maxFileSize: 100,
    });
    expect(Array.isArray(result)).toBe(true);
    result.forEach((item) => {
      const size = parseFloat(item.fileSize || "0");
      expect(size).toBeGreaterThanOrEqual(50);
      expect(size).toBeLessThanOrEqual(100);
    });
  });

  it("should sort by downloads descending", async () => {
    const result = await filterSoftware({
      sortBy: "downloads",
      sortOrder: "desc",
      limit: 5,
    });
    expect(Array.isArray(result)).toBe(true);
    for (let i = 1; i < result.length; i++) {
      expect(result[i].downloadCount).toBeLessThanOrEqual(
        result[i - 1].downloadCount
      );
    }
  });

  it("should sort by file size ascending", async () => {
    const result = await filterSoftware({
      sortBy: "fileSize",
      sortOrder: "asc",
      limit: 5,
    });
    expect(Array.isArray(result)).toBe(true);
    for (let i = 1; i < result.length; i++) {
      const prevSize = parseFloat(result[i - 1].fileSize || "0");
      const currSize = parseFloat(result[i].fileSize || "0");
      expect(currSize).toBeGreaterThanOrEqual(prevSize);
    }
  });

  it("should sort by name", async () => {
    const result = await filterSoftware({
      sortBy: "name",
      sortOrder: "asc",
      limit: 5,
    });
    expect(Array.isArray(result)).toBe(true);
    for (let i = 1; i < result.length; i++) {
      expect(result[i].name.localeCompare(result[i - 1].name)).toBeGreaterThanOrEqual(0);
    }
  });

  it("should apply pagination", async () => {
    const result1 = await filterSoftware({ limit: 5, offset: 0 });
    const result2 = await filterSoftware({ limit: 5, offset: 5 });
    expect(result1.length).toBeLessThanOrEqual(5);
    expect(result2.length).toBeLessThanOrEqual(5);
    // Results should be different
    if (result1.length > 0 && result2.length > 0) {
      expect(result1[0].id).not.toBe(result2[0].id);
    }
  });

  it("should combine multiple filters", async () => {
    const result = await filterSoftware({
      category: "Windows",
      minDownloads: 1000,
      maxDownloads: 10000,
      sortBy: "downloads",
      sortOrder: "desc",
    });
    expect(Array.isArray(result)).toBe(true);
    result.forEach((item) => {
      expect(item.category).toBe("Windows");
      expect(item.downloadCount).toBeGreaterThanOrEqual(1000);
      expect(item.downloadCount).toBeLessThanOrEqual(10000);
    });
  });
});
