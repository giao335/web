import { eq, desc, sql } from "drizzle-orm";
import { software, downloadStats, categories } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Get all software with optional category filter
 */
export async function getSoftware(category?: string) {
  const db = await getDb();
  if (!db) return [];

  try {
    if (category) {
      return await db
        .select()
        .from(software)
        .where(eq(software.category, category));
    }
    return await db.select().from(software);
  } catch (error) {
    console.error("[Database] Failed to get software:", error);
    return [];
  }
}

/**
 * Get top downloaded software (for rankings)
 */
export async function getTopSoftware(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(software)
      .orderBy(desc(software.downloadCount))
      .limit(limit);
  } catch (error) {
    console.error("[Database] Failed to get top software:", error);
    return [];
  }
}

/**
 * Get all categories
 */
export async function getCategories() {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db.select().from(categories);
  } catch (error) {
    console.error("[Database] Failed to get categories:", error);
    return [];
  }
}

/**
 * Record a download event and increment download count
 */
export async function recordDownload(softwareId: number, userId?: number) {
  const db = await getDb();
  if (!db) return false;

  try {
    // Record download stats
    await db.insert(downloadStats).values({
      softwareId,
      userId: userId || null,
    });

    // Increment download count
    await db
      .update(software)
      .set({
        downloadCount: sql`${software.downloadCount} + 1`,
      })
      .where(eq(software.id, softwareId));

    return true;
  } catch (error) {
    console.error("[Database] Failed to record download:", error);
    return false;
  }
}

/**
 * Get download statistics for a software
 */
export async function getDownloadStats(softwareId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .select()
      .from(software)
      .where(eq(software.id, softwareId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get download stats:", error);
    return null;
  }
}

/**
 * Get software by ID
 */
export async function getSoftwareById(id: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .select()
      .from(software)
      .where(eq(software.id, id))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get software by ID:", error);
    return null;
  }
}

/**
 * Filter software by multiple dimensions
 */
export interface FilterOptions {
  category?: string;
  minFileSize?: number; // in MB
  maxFileSize?: number; // in MB
  minRating?: number; // 0-5
  maxRating?: number; // 0-5
  minDownloads?: number;
  maxDownloads?: number;
  sortBy?: 'downloads' | 'rating' | 'fileSize' | 'name';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export async function filterSoftware(options: FilterOptions) {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get all software as base
    let results = await db.select().from(software);

    // Apply category filter
    if (options.category) {
      results = results.filter(item => item.category === options.category);
    }

    // Apply download count filters
    if (options.minDownloads !== undefined) {
      const minDownloads = options.minDownloads;
      results = results.filter(item => item.downloadCount >= minDownloads);
    }
    if (options.maxDownloads !== undefined) {
      const maxDownloads = options.maxDownloads;
      results = results.filter(item => item.downloadCount <= maxDownloads);
    }

    // Apply file size filters
    if (options.minFileSize !== undefined || options.maxFileSize !== undefined) {
      results = results.filter((item) => {
        const sizeStr = item.fileSize || "0MB";
        const sizeNum = parseFloat(sizeStr);
        if (options.minFileSize !== undefined && sizeNum < options.minFileSize) {
          return false;
        }
        if (options.maxFileSize !== undefined && sizeNum > options.maxFileSize) {
          return false;
        }
        return true;
      });
    }

    // Sort
    if (options.sortBy === 'downloads') {
      results.sort((a, b) =>
        options.sortOrder === 'asc'
          ? a.downloadCount - b.downloadCount
          : b.downloadCount - a.downloadCount
      );
    } else if (options.sortBy === 'fileSize') {
      results.sort((a, b) => {
        const aSize = parseFloat(a.fileSize || "0");
        const bSize = parseFloat(b.fileSize || "0");
        return options.sortOrder === 'asc' ? aSize - bSize : bSize - aSize;
      });
    } else if (options.sortBy === 'name') {
      results.sort((a, b) =>
        options.sortOrder === 'asc'
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name)
      );
    }

    // Pagination
    const offset = options.offset || 0;
    const limit = options.limit || 20;
    return results.slice(offset, offset + limit);
  } catch (error) {
    console.error("[Database] Failed to filter software:", error);
    return [];
  }
}
