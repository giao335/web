# 五谷杂粮下载中心 - 阿里云部署指南

## 项目概述

**项目名称**: 五谷杂粮下载中心  
**技术栈**: React 19 + Tailwind 4 + Express 4 + tRPC 11 + MySQL/TiDB  
**功能**: 多平台软件下载中心，包含深色模式、高级搜索、分类浏览、热门网站推荐和丰富的交互动画

## 前置要求

- Node.js 22.13.0 或更高版本
- pnpm 包管理器
- MySQL 8.0+ 或兼容数据库
- 阿里云账户（ECS、RDS、OSS 等服务）

## 环境变量配置

### 必需的环境变量

创建 `.env.local` 文件，配置以下变量：

```env
# 数据库连接
DATABASE_URL=mysql://user:password@host:3306/wugu_downloads

# OAuth 认证（可选，如果需要用户登录）
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
JWT_SECRET=your_jwt_secret_key

# 应用信息
VITE_APP_TITLE=五谷杂粮下载中心
VITE_APP_LOGO=https://your-cdn.com/logo.png

# 所有者信息
OWNER_NAME=Your Name
OWNER_OPEN_ID=your_open_id

# 可选：S3 存储（用于上传文件）
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_S3_BUCKET=your_bucket_name
```

## 部署步骤

### 1. 准备阿里云基础设施

#### 1.1 创建 ECS 实例
- **操作系统**: Ubuntu 22.04 LTS
- **实例类型**: t6-standard-2 或更高（2核4GB内存）
- **存储**: 50GB SSD
- **网络**: 配置安全组，开放 80、443、3306 端口

#### 1.2 创建 RDS MySQL 实例
- **引擎**: MySQL 8.0
- **实例规格**: db.t3.small 或更高
- **存储**: 20GB
- **备份**: 启用自动备份

#### 1.3 配置域名和 DNS
- 购买或绑定域名
- 配置 DNS 指向 ECS 实例公网 IP
- 申请 SSL 证书（阿里云免费提供）

### 2. 在 ECS 上部署应用

#### 2.1 连接到 ECS 实例

```bash
ssh -i your_key.pem ubuntu@your_ecs_ip
```

#### 2.2 安装依赖

```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装 Node.js 和 pnpm
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
npm install -g pnpm

# 安装 Nginx（反向代理）
sudo apt install -y nginx

# 安装 PM2（进程管理）
sudo npm install -g pm2

# 安装 Git
sudo apt install -y git
```

#### 2.3 克隆项目代码

```bash
cd /home/ubuntu
git clone https://github.com/your-repo/wugu_downloads.git
cd wugu_downloads
```

#### 2.4 安装项目依赖

```bash
pnpm install
```

#### 2.5 配置环境变量

```bash
# 创建 .env.local 文件
nano .env.local

# 粘贴上面的环境变量配置
# 按 Ctrl+X, Y, Enter 保存
```

#### 2.6 构建项目

```bash
pnpm build
```

#### 2.7 运行数据库迁移

```bash
pnpm db:push
```

#### 2.8 启动应用

```bash
# 使用 PM2 启动应用
pm2 start dist/index.js --name "wugu-downloads" --instances max

# 配置 PM2 开机自启
pm2 startup
pm2 save
```

### 3. 配置 Nginx 反向代理

#### 3.1 编辑 Nginx 配置

```bash
sudo nano /etc/nginx/sites-available/default
```

#### 3.2 配置文件内容

```nginx
upstream wugu_downloads {
    server 127.0.0.1:3000;
}

server {
    listen 80;
    server_name your_domain.com;

    # 重定向到 HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your_domain.com;

    # SSL 证书配置
    ssl_certificate /path/to/your/certificate.crt;
    ssl_certificate_key /path/to/your/private.key;

    # SSL 安全配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # 日志
    access_log /var/log/nginx/wugu_downloads_access.log;
    error_log /var/log/nginx/wugu_downloads_error.log;

    # 反向代理
    location / {
        proxy_pass http://wugu_downloads;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Gzip 压缩
    gzip on;
    gzip_types text/plain text/css text/javascript application/json application/javascript;
    gzip_min_length 1000;
}
```

#### 3.3 测试和启动 Nginx

```bash
# 测试配置
sudo nginx -t

# 启动 Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 4. 配置 SSL 证书（阿里云）

#### 4.1 申请免费 SSL 证书
1. 登录阿里云控制台
2. 进入 SSL 证书服务
3. 申请免费证书
4. 验证域名所有权
5. 下载证书

#### 4.2 部署证书到 Nginx

```bash
# 将证书文件上传到 ECS
scp -i your_key.pem your_cert.crt ubuntu@your_ecs_ip:/home/ubuntu/
scp -i your_key.pem your_key.key ubuntu@your_ecs_ip:/home/ubuntu/

# 移动到 Nginx 目录
sudo mv /home/ubuntu/your_cert.crt /etc/nginx/ssl/
sudo mv /home/ubuntu/your_key.key /etc/nginx/ssl/
sudo chmod 600 /etc/nginx/ssl/*
```

### 5. 数据库配置

#### 5.1 连接到 RDS MySQL

```bash
mysql -h your_rds_endpoint.rds.aliyuncs.com -u admin -p
```

#### 5.2 创建数据库

```sql
CREATE DATABASE wugu_downloads CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

#### 5.3 导入初始数据（可选）

```bash
mysql -h your_rds_endpoint.rds.aliyuncs.com -u admin -p wugu_downloads < initial_data.sql
```

### 6. 监控和维护

#### 6.1 查看应用日志

```bash
# PM2 日志
pm2 logs wugu-downloads

# Nginx 日志
sudo tail -f /var/log/nginx/wugu_downloads_access.log
sudo tail -f /var/log/nginx/wugu_downloads_error.log
```

#### 6.2 性能监控

```bash
# 使用 PM2 监控
pm2 monit

# 查看系统资源
top
```

#### 6.3 定期备份

```bash
# 备份数据库
mysqldump -h your_rds_endpoint -u admin -p wugu_downloads > backup_$(date +%Y%m%d).sql

# 备份应用代码
tar -czf wugu_downloads_backup_$(date +%Y%m%d).tar.gz /home/ubuntu/wugu_downloads/
```

## 性能优化

### 1. 数据库优化

```sql
-- 添加索引
CREATE INDEX idx_category ON applications(category_id);
CREATE INDEX idx_rating ON applications(rating);
CREATE FULLTEXT INDEX ft_name ON applications(name);

-- 启用查询缓存
SET GLOBAL query_cache_type = 1;
SET GLOBAL query_cache_size = 268435456; -- 256MB
```

### 2. 应用优化

```bash
# 启用 Node.js 集群模式
pm2 start dist/index.js --instances max

# 启用 Gzip 压缩（已在 Nginx 配置中）
```

### 3. CDN 加速（可选）

配置阿里云 CDN 加速静态资源：

```bash
# 在 Nginx 配置中添加 CDN 源站
upstream cdn_origin {
    server your_domain.com;
}
```

## 故障排查

### 问题 1: 应用无法启动

```bash
# 检查 PM2 日志
pm2 logs wugu-downloads

# 检查端口占用
sudo lsof -i :3000

# 检查环境变量
cat .env.local
```

### 问题 2: 数据库连接失败

```bash
# 测试数据库连接
mysql -h your_rds_endpoint -u admin -p -e "SELECT 1;"

# 检查安全组规则
# 确保 RDS 安全组允许 ECS 实例的访问
```

### 问题 3: 页面加载缓慢

```bash
# 检查 Nginx 日志
sudo tail -f /var/log/nginx/wugu_downloads_error.log

# 检查应用性能
pm2 monit

# 启用 Gzip 压缩
# 已在 Nginx 配置中启用
```

## 自动化部署（可选）

使用 GitHub Actions 实现自动化部署：

```yaml
name: Deploy to Aliyun

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '22'
      - run: npm install -g pnpm
      - run: pnpm install
      - run: pnpm build
      - name: Deploy to Aliyun
        run: |
          # 部署脚本
          scp -i ${{ secrets.DEPLOY_KEY }} -r dist/ ubuntu@${{ secrets.ALIYUN_IP }}:/home/ubuntu/wugu_downloads/
          ssh -i ${{ secrets.DEPLOY_KEY }} ubuntu@${{ secrets.ALIYUN_IP }} 'pm2 restart wugu-downloads'
```

## 安全建议

1. **定期更新依赖**
   ```bash
   pnpm update
   ```

2. **启用防火墙**
   ```bash
   sudo ufw enable
   sudo ufw allow 22/tcp
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   ```

3. **配置 DDoS 防护**
   - 使用阿里云 DDoS 防护服务
   - 配置 WAF（Web 应用防火墙）

4. **定期备份**
   - 数据库自动备份
   - 应用代码版本控制

5. **监控和告警**
   - 配置阿里云云监控
   - 设置告警规则

## 支持和资源

- 项目文档: `/home/ubuntu/wugu_downloads/README.md`
- 技能文档: `/home/ubuntu/skills/modern-download-center/SKILL.md`
- 阿里云文档: https://help.aliyun.com/
- Node.js 文档: https://nodejs.org/docs/

## 许可证

该项目遵循相关许可证。详见项目根目录的 LICENSE 文件。
