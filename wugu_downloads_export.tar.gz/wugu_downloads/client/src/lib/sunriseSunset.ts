/**
 * 日出日落时间计算工具
 * 基于简化的天文计算公式
 */

interface SunTimes {
  sunrise: Date;
  sunset: Date;
}

/**
 * 计算给定日期和位置的日出日落时间
 * 使用简化的天文算法
 * @param date 计算日期
 * @param latitude 纬度 (-90 to 90)
 * @param longitude 经度 (-180 to 180)
 * @returns 日出和日落时间
 */
export function calculateSunTimes(
  date: Date,
  latitude: number,
  longitude: number
): SunTimes {
  const J2000 = 2451545.0; // Julian Date for 2000-01-01 12:00:00
  const JD = getJulianDate(date) + 0.5;

  // 计算太阳的赤经和赤纬
  const n = JD - J2000;
  const L = (280.46646 + 0.0036841 * n) % 360;
  const g = (357.52911 + 0.0003032 * n) % 360;

  const e = 0.016708634 - 0.000042037 * n - 0.0000001267 * n * n;
  const C =
    (1.914602 - 0.004817 * n - 0.000014 * n * n) * Math.sin(toRad(g)) +
    (0.019993 - 0.000101 * n) * Math.sin(toRad(2 * g)) +
    0.000029 * Math.sin(toRad(3 * g));

  const sunLong = L + C;
  const sunAnomaly = g + C;
  const sunDist =
    (1.000001018 * (1 - e * e)) / (1 + e * Math.cos(toRad(sunAnomaly)));

  const epsilon = 23.439291 - 0.0130042 * n - 0.00000164 * n * n + 0.000000504 * n * n * n;

  const sunRA = Math.atan2(
    Math.cos(toRad(epsilon)) * Math.sin(toRad(sunLong)),
    Math.cos(toRad(sunLong))
  );
  const sunDec = Math.asin(Math.sin(toRad(epsilon)) * Math.sin(toRad(sunLong)));

  // 计算日出日落时间
  const latRad = toRad(latitude);
  const cosH = -Math.tan(latRad) * Math.tan(sunDec);

  // 处理极地情况
  if (cosH > 1) {
    // 极夜（整日黑暗）
    return {
      sunrise: new Date(date.getTime() + 12 * 60 * 60 * 1000),
      sunset: new Date(date.getTime() + 12 * 60 * 60 * 1000),
    };
  } else if (cosH < -1) {
    // 极昼（整日光亮）
    return {
      sunrise: new Date(date.getTime()),
      sunset: new Date(date.getTime() + 24 * 60 * 60 * 1000),
    };
  }

  const H = Math.acos(cosH);
  const JDrise = JD + (360 - toDeg(sunRA) - longitude) / 360 - H / (2 * Math.PI);
  const JDset = JD + (360 - toDeg(sunRA) - longitude) / 360 + H / (2 * Math.PI);

  return {
    sunrise: julianDateToDate(JDrise),
    sunset: julianDateToDate(JDset),
  };
}

/**
 * 将日期转换为儒略日数
 */
function getJulianDate(date: Date): number {
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  const hour = date.getUTCHours();
  const minute = date.getUTCMinutes();
  const second = date.getUTCSeconds();

  let a = Math.floor((14 - month) / 12);
  let y = year + 4800 - a;
  let m = month + 12 * a - 3;

  let jdn =
    day +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045;

  let jd = jdn + (hour - 12) / 24 + minute / 1440 + second / 86400;

  return jd;
}

/**
 * 将儒略日数转换为日期
 */
function julianDateToDate(jd: number): Date {
  const Z = Math.floor(jd + 0.5);
  const F = jd + 0.5 - Z;

  let A = Z;
  if (Z < 2299161) {
    A = Z;
  } else {
    const alpha = Math.floor((Z - 1867216.25) / 36524.25);
    A = Z + 1 + alpha - Math.floor(alpha / 4);
  }

  const B = A + 1524;
  const C = Math.floor((B - 122.1) / 365.25);
  const D = Math.floor(365.25 * C);
  const E = Math.floor((B - D) / 30.6001);

  const day = B - D - Math.floor(30.6001 * E) + F;
  const month = E < 14 ? E - 1 : E - 13;
  const year = month > 2 ? C - 4716 : C - 4715;

  const dayInt = Math.floor(day);
  const hour = Math.floor((day - dayInt) * 24);
  const minute = Math.floor(((day - dayInt) * 24 - hour) * 60);
  const second = Math.floor((((day - dayInt) * 24 - hour) * 60 - minute) * 60);

  return new Date(Date.UTC(year, month - 1, dayInt, hour, minute, second));
}

/**
 * 角度转弧度
 */
function toRad(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

/**
 * 弧度转角度
 */
function toDeg(radians: number): number {
  return (radians * 180) / Math.PI;
}

/**
 * 检查当前时间是否在日出日落之间
 */
export function isDaytime(sunTimes: SunTimes, currentTime: Date = new Date()): boolean {
  return currentTime >= sunTimes.sunrise && currentTime < sunTimes.sunset;
}

/**
 * 获取用户的地理位置（使用浏览器 Geolocation API）
 */
export function getUserLocation(): Promise<{ latitude: number; longitude: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        reject(error);
      }
    );
  });
}

/**
 * 从 localStorage 获取保存的位置信息
 */
export function getSavedLocation(): { latitude: number; longitude: number } | null {
  try {
    const saved = localStorage.getItem("themeAutoSwitchLocation");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to parse saved location:", e);
  }
  return null;
}

/**
 * 保存位置信息到 localStorage
 */
export function saveLocation(latitude: number, longitude: number): void {
  try {
    localStorage.setItem(
      "themeAutoSwitchLocation",
      JSON.stringify({ latitude, longitude })
    );
  } catch (e) {
    console.error("Failed to save location:", e);
  }
}
