import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, X } from "lucide-react";

export interface FilterState {
  category?: string;
  appType?: string;
  minFileSize?: number;
  maxFileSize?: number;
  minDownloads?: number;
  maxDownloads?: number;
  sortBy?: 'downloads' | 'rating' | 'fileSize' | 'name';
  sortOrder?: 'asc' | 'desc';
}

interface FilterPanelProps {
  categories: Array<{ id: number; name: string }>;
  onFilterChange: (filters: FilterState) => void;
  isOpen?: boolean;
}

export function FilterPanel({ categories, onFilterChange, isOpen = false }: FilterPanelProps) {
  const [expanded, setExpanded] = useState(isOpen);
  const [filters, setFilters] = useState<FilterState>({});
  const [fileSizeRange, setFileSizeRange] = useState<[number, number]>([0, 500]);
  const [downloadRange, setDownloadRange] = useState<[number, number]>([0, 100000]);

  const handleCategoryChange = (value: string) => {
    const newFilters = { ...filters, category: value || undefined };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleFileSizeChange = (value: [number, number]) => {
    setFileSizeRange(value);
    const newFilters = {
      ...filters,
      minFileSize: value[0],
      maxFileSize: value[1],
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleDownloadRangeChange = (value: [number, number]) => {
    setDownloadRange(value);
    const newFilters = {
      ...filters,
      minDownloads: value[0],
      maxDownloads: value[1],
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleSortChange = (value: string) => {
    const [sortBy, sortOrder] = value.split('-') as ['downloads' | 'rating' | 'fileSize' | 'name', 'asc' | 'desc'];
    const newFilters = { ...filters, sortBy, sortOrder };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const resetFilters = () => {
    setFilters({});
    setFileSizeRange([0, 500]);
    setDownloadRange([0, 100000]);
    onFilterChange({});
  };

  const hasActiveFilters = Object.values(filters).some(v => v !== undefined);

  return (
    <div className="w-full">
      <motion.button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-4 py-3 bg-card border border-border rounded-lg hover:bg-accent/5 transition-colors"
        whileHover={{ backgroundColor: "var(--color-accent-5)" }}
      >
        <span className="font-semibold text-foreground flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
          </svg>
          筛选
          {hasActiveFilters && (
            <span className="ml-2 px-2 py-1 bg-accent text-accent-foreground text-xs rounded-full">
              已激活
            </span>
          )}
        </span>
        <ChevronDown
          className={`w-5 h-5 transition-transform ${expanded ? "rotate-180" : ""}`}
        />
      </motion.button>

      <motion.div
        initial={false}
        animate={{ height: expanded ? "auto" : 0, opacity: expanded ? 1 : 0 }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <Card className="mt-3 p-6 space-y-6">
          {/* Category Filter */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              平台分类
            </label>
            <Select value={filters.category || "all"} onValueChange={(val) => handleCategoryChange(val === "all" ? "" : val)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择平台..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部平台</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* File Size Range */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-4">
              文件大小: {fileSizeRange[0]}MB - {fileSizeRange[1]}MB
            </label>
            <Slider
              defaultValue={fileSizeRange}
              min={0}
              max={500}
              step={10}
              onValueChange={handleFileSizeChange}
              className="w-full"
            />
          </div>

          {/* Download Count Range */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-4">
              下载次数: {downloadRange[0].toLocaleString()} - {downloadRange[1].toLocaleString()}
            </label>
            <Slider
              defaultValue={downloadRange}
              min={0}
              max={100000}
              step={1000}
              onValueChange={handleDownloadRangeChange}
              className="w-full"
            />
          </div>

          {/* Sort Options */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              排序方式
            </label>
            <Select
              value={filters.sortBy ? `${filters.sortBy}-${filters.sortOrder || 'desc'}` : "default"}
              onValueChange={(val) => handleSortChange(val === "default" ? "" : val)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择排序方式..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">默认排序</SelectItem>
                <SelectItem value="downloads-desc">下载次数 (高到低)</SelectItem>
                <SelectItem value="downloads-asc">下载次数 (低到高)</SelectItem>
                <SelectItem value="fileSize-asc">文件大小 (小到大)</SelectItem>
                <SelectItem value="fileSize-desc">文件大小 (大到小)</SelectItem>
                <SelectItem value="name-asc">名称 (A-Z)</SelectItem>
                <SelectItem value="name-desc">名称 (Z-A)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              onClick={resetFilters}
              variant="outline"
              className="flex-1"
            >
              <X className="w-4 h-4 mr-2" />
              重置筛选
            </Button>
            <Button
              onClick={() => setExpanded(false)}
              className="flex-1"
            >
              应用筛选
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
