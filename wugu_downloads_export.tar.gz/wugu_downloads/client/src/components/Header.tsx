import { motion } from "framer-motion";
import { UserMenu } from "./UserMenu";
import { SearchBar } from "./SearchBar";
import { useLocation } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";
import { Moon, Sun } from "lucide-react";
import type { User } from "@shared/types";

interface HeaderProps {
  user: User | null;
  loading: boolean;
  onLogout: () => void;
  onSearch: (query: string) => void;
}

export function Header({ user, loading, onLogout, onSearch }: HeaderProps) {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  const isActive = (path: string) => location === path;

  return (
    <motion.header
      className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div className="container mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-4 mb-4">
          {/* Logo */}
          <motion.a
            href="/"
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-lg">五</span>
            </div>
            <h1 className="text-xl font-bold text-foreground hidden sm:block">
              五谷杂粮
            </h1>
          </motion.a>

          {/* Navigation Links */}
          <div className="flex items-center gap-6">
            <motion.a
              href="/rankings"
              className={`text-sm font-medium transition-colors duration-200 ${
                isActive("/rankings")
                  ? "text-accent"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              whileHover={{ scale: 1.05 }}
            >
              排行榜
            </motion.a>

            {/* Theme Toggle */}
            <motion.button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-secondary transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              title={theme === 'light' ? '切换到深色模式' : '切换到浅色模式'}
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5 text-muted-foreground" />
              ) : (
                <Sun className="w-5 h-5 text-muted-foreground" />
              )}
            </motion.button>

            {/* User Menu */}
            <UserMenu user={user} loading={loading} onLogout={onLogout} />
          </div>
        </div>

        {/* Search Bar - only show on home page */}
        {isActive("/") && <SearchBar onSearch={onSearch} />}
      </div>
    </motion.header>
  );
}
