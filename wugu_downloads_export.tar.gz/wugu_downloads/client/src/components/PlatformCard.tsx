import { Button } from "@/components/ui/button";
import { Download, ExternalLink } from "lucide-react";
import { ReactNode } from "react";

interface DownloadLink {
  label: string;
  url: string;
  version?: string;
}

interface PlatformCardProps {
  icon: ReactNode;
  name: string;
  description: string;
  downloads: DownloadLink[];
  color?: string;
}

/**
 * PlatformCard Component
 * 
 * Design Philosophy: Modern Minimalism
 * - Clean white card with subtle shadow
 * - Clear typography hierarchy with Poppins headings
 * - Blue accent color for CTAs
 * - Smooth hover effects (200-300ms transitions)
 * - Ample whitespace for breathing room
 * - Rich animations for enhanced interactivity
 */
export function PlatformCard({
  icon,
  name,
  description,
  downloads,
  color = "#2563EB",
}: PlatformCardProps) {
  return (
    <div className="group relative bg-card text-card-foreground rounded-xl border border-border p-6 hover:shadow-xl transition-all duration-300 hover:border-accent/30 hover:scale-105 cursor-pointer overflow-hidden">
      {/* Animated background gradient on hover */}
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300"
        style={{
          background: `linear-gradient(135deg, ${color}, transparent)`,
        }}
      />

      {/* Icon and Title Section */}
      <div className="flex items-start gap-4 mb-4 relative z-10">
        <div
          className="flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg"
          style={{ backgroundColor: `${color}15` }}
        >
          <div
            className="transition-transform duration-300 group-hover:rotate-12"
            style={{ color }}
          >
            {icon}
          </div>
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-foreground mb-1 group-hover:text-accent transition-colors duration-300">
            {name}
          </h3>
          <p className="text-sm text-muted-foreground group-hover:text-muted-foreground/80 transition-colors duration-300">
            {description}
          </p>
        </div>
      </div>

      {/* Download Links */}
      <div className="space-y-2 mt-6 relative z-10">
        {downloads.map((download, index) => (
          <a
            key={index}
            href={download.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3 rounded-lg bg-secondary hover:bg-accent/10 transition-all duration-200 group/link hover:translate-x-1"
          >
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <Download className="w-4 h-4 text-accent flex-shrink-0 group-hover/link:animate-bounce" />
              <span className="text-sm font-medium text-foreground truncate group-hover/link:text-accent transition-colors duration-200">
                {download.label}
              </span>
              {download.version && (
                <span className="text-xs text-muted-foreground flex-shrink-0 group-hover/link:text-accent/70 transition-colors duration-200">
                  {download.version}
                </span>
              )}
            </div>
            <ExternalLink className="w-4 h-4 text-muted-foreground group-hover/link:text-accent transition-all duration-200 flex-shrink-0 ml-2 group-hover/link:translate-x-1 group-hover/link:-translate-y-1" />
          </a>
        ))}
      </div>

      {/* Decorative accent line with animation */}
      <div
        className="absolute top-0 left-0 right-0 h-1 rounded-t-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          backgroundColor: color,
        }}
      />

      {/* Glow effect on hover */}
      <div
        className="absolute -inset-0.5 opacity-0 group-hover:opacity-20 transition-opacity duration-300 rounded-xl blur pointer-events-none"
        style={{ backgroundColor: color }}
      />
    </div>
  );
}
