import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export function WelcomeDialog() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // 检查是否已显示过欢迎弹窗
    const hasShownWelcome = localStorage.getItem("wugu_welcome_shown");
    if (!hasShownWelcome) {
      setOpen(true);
      localStorage.setItem("wugu_welcome_shown", "true");
    }
  }, []);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3 }}
            className="flex justify-center mb-4"
          >
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-full">
              <AlertCircle className="w-6 h-6 text-yellow-600 dark:text-yellow-500" />
            </div>
          </motion.div>
          <DialogTitle className="text-center text-lg">
            网站测试阶段
          </DialogTitle>
        </DialogHeader>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <DialogDescription className="text-center space-y-4">
            <p className="text-base">
              欢迎来到五谷杂粮下载中心！我们的网站目前处于测试阶段。
            </p>
            <p className="text-sm text-muted-foreground">
              如果您有任何建议或反馈，欢迎点击页面最下方的"联系我们"与我们沟通。
            </p>
            <p className="text-sm font-medium text-accent">
              感谢您的支持！
            </p>
          </DialogDescription>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="flex gap-3 mt-6"
        >
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => setOpen(false)}
          >
            关闭
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              setOpen(false);
              // 滚动到页脚
              const footer = document.querySelector("footer");
              footer?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            联系我们
          </Button>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
