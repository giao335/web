import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Github,
  Code,
  BookOpen,
  Play,
  Film,
  Music,
  Cloud,
  Database,
  Palette,
  Image,
  MessageCircle,
  Zap,
  ExternalLink,
  ChevronRight,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { websitesData } from "@shared/appData";

interface PopularWebsitesProps {
  limit?: number;
  showAll?: boolean;
}

// Icon mapping
const iconMap: Record<string, React.ReactNode> = {
  Github: <Github className="w-5 h-5" />,
  Code: <Code className="w-5 h-5" />,
  BookOpen: <BookOpen className="w-5 h-5" />,
  Play: <Play className="w-5 h-5" />,
  Film: <Film className="w-5 h-5" />,
  Music: <Music className="w-5 h-5" />,
  Cloud: <Cloud className="w-5 h-5" />,
  Database: <Database className="w-5 h-5" />,
  Palette: <Palette className="w-5 h-5" />,
  Image: <Image className="w-5 h-5" />,
  MessageCircle: <MessageCircle className="w-5 h-5" />,
  Zap: <Zap className="w-5 h-5" />,
};

// Category colors
const categoryColors: Record<string, string> = {
  Development: "from-blue-500/10 to-blue-600/10",
  Media: "from-purple-500/10 to-purple-600/10",
  Productivity: "from-green-500/10 to-green-600/10",
  Design: "from-pink-500/10 to-pink-600/10",
  AI: "from-orange-500/10 to-orange-600/10",
};

export function PopularWebsites({
  limit = 6,
  showAll = false,
}: PopularWebsitesProps) {
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const displayedWebsites = showAll ? websitesData : websitesData.slice(0, limit);

  // Group websites by category
  const groupedWebsites = displayedWebsites.reduce(
    (acc, website) => {
      const category = website.category;
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(website);
      return acc;
    },
    {} as Record<string, typeof websitesData>
  );

  const categories = Object.keys(groupedWebsites).sort();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="w-full space-y-6"
    >
      <div className="space-y-2">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          className="text-3xl font-bold text-foreground"
        >
          热门网址
        </motion.h2>
        <p className="text-muted-foreground">
          快速访问最受欢迎的开发、媒体和生产力工具
        </p>
      </div>

      {/* Websites Grid by Category */}
      <div className="space-y-6">
        <AnimatePresence mode="wait">
          {categories.map((category, categoryIndex) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: categoryIndex * 0.1 }}
              className="space-y-3"
            >
              {/* Category Header */}
              <motion.button
                whileHover={{ x: 4 }}
                onClick={() =>
                  setExpandedCategory(
                    expandedCategory === category ? null : category
                  )
                }
                className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-accent/10 transition-colors group"
              >
                <span className="text-sm font-semibold text-foreground">
                  {category}
                </span>
                <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                  {groupedWebsites[category].length}
                </span>
                <motion.div
                  animate={{
                    rotate:
                      expandedCategory === category ? 90 : 0,
                  }}
                  transition={{ duration: 0.2 }}
                  className="ml-auto"
                >
                  <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                </motion.div>
              </motion.button>

              {/* Websites Grid */}
              <AnimatePresence>
                {(expandedCategory === category || !expandedCategory) && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"
                  >
                    <AnimatePresence>
                      {groupedWebsites[category].map((website, index) => (
                        <motion.div
                          key={website.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          transition={{ delay: index * 0.05 }}
                          onMouseEnter={() => setHoveredId(website.id)}
                          onMouseLeave={() => setHoveredId(null)}
                        >
                          <motion.a
                            href={website.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            whileHover={{ scale: 1.02, y: -4 }}
                            whileTap={{ scale: 0.98 }}
                            className={`block p-4 rounded-lg border border-border bg-gradient-to-br ${
                              categoryColors[category] || "from-gray-500/10 to-gray-600/10"
                            } hover:border-accent/50 transition-all cursor-pointer group`}
                          >
                            <div className="flex items-start justify-between mb-3">
                              <motion.div
                                animate={{
                                  scale: hoveredId === website.id ? 1.1 : 1,
                                }}
                                transition={{ duration: 0.2 }}
                                className="p-2 rounded-lg bg-background/50 group-hover:bg-accent/20 transition-colors"
                              >
                                {website.icon
                                  ? iconMap[website.icon]
                                  : iconMap["Zap"]}
                              </motion.div>
                              <motion.div
                                animate={{
                                  x: hoveredId === website.id ? 4 : 0,
                                }}
                                transition={{ duration: 0.2 }}
                              >
                                <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-accent transition-colors" />
                              </motion.div>
                            </div>

                            <div className="space-y-1">
                              <h3 className="font-semibold text-foreground group-hover:text-accent transition-colors">
                                {website.name}
                              </h3>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {website.description}
                              </p>
                            </div>

                            {/* Hover Indicator */}
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{
                                width: hoveredId === website.id ? "100%" : 0,
                              }}
                              transition={{ duration: 0.3 }}
                              className="mt-3 h-1 bg-gradient-to-r from-accent to-accent/50 rounded-full"
                            />
                          </motion.a>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* View All Button */}
      {!showAll && websitesData.length > limit && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex justify-center pt-4"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-2 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 transition-colors font-medium flex items-center gap-2"
          >
            查看全部热门网址
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </motion.div>
      )}
    </motion.div>
  );
}
