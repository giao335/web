import React, { useState } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { Sun, Moon, MapPin, Loader2 } from "lucide-react";
import { getUserLocation } from "@/lib/sunriseSunset";
import { ThemePreview } from "./ThemePreview";

export function ThemeSettings() {
  const { theme, toggleTheme, autoSwitchMode, setAutoSwitchMode, location, setLocation } = useTheme();
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [manualLatitude, setManualLatitude] = useState(location?.latitude.toString() || "");
  const [manualLongitude, setManualLongitude] = useState(location?.longitude.toString() || "");

  const handleGetLocation = async () => {
    setIsLoadingLocation(true);
    setLocationError(null);
    try {
      const userLocation = await getUserLocation();
      setLocation(userLocation);
      setManualLatitude(userLocation.latitude.toString());
      setManualLongitude(userLocation.longitude.toString());
    } catch (error) {
      setLocationError(
        error instanceof Error ? error.message : "无法获取位置信息"
      );
    } finally {
      setIsLoadingLocation(false);
    }
  };

  const handleSaveManualLocation = () => {
    const lat = parseFloat(manualLatitude);
    const lon = parseFloat(manualLongitude);

    if (isNaN(lat) || isNaN(lon)) {
      setLocationError("请输入有效的纬度和经度");
      return;
    }

    if (lat < -90 || lat > 90) {
      setLocationError("纬度必须在 -90 到 90 之间");
      return;
    }

    if (lon < -180 || lon > 180) {
      setLocationError("经度必须在 -180 到 180 之间");
      return;
    }

    setLocation({ latitude: lat, longitude: lon });
    setLocationError(null);
  };

  const handleThemeSelect = (selectedTheme: "light" | "dark") => {
    // 如果选择的主题与当前主题不同，则切换
    if (selectedTheme !== theme && toggleTheme) {
      toggleTheme();
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sun className="w-5 h-5" />
          主题设置
        </CardTitle>
        <CardDescription>自定义深色模式的自动切换方式</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* 主题预览 */}
        <ThemePreview currentTheme={theme} onThemeSelect={handleThemeSelect} />

        {/* 分隔线 */}
        <div className="border-t" />

        {/* 自动切换模式选择 */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">自动切换模式</Label>
          <RadioGroup value={autoSwitchMode} onValueChange={(value) => setAutoSwitchMode(value as any)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="off" id="mode-off" />
              <Label htmlFor="mode-off" className="font-normal cursor-pointer">
                关闭自动切换
              </Label>
            </div>
            <p className="text-sm text-muted-foreground ml-6 mb-3">
              手动切换主题，不自动调整
            </p>

            <div className="flex items-center space-x-2">
              <RadioGroupItem value="system" id="mode-system" />
              <Label htmlFor="mode-system" className="font-normal cursor-pointer">
                跟随系统设置
              </Label>
            </div>
            <p className="text-sm text-muted-foreground ml-6 mb-3">
              根据操作系统的深色模式设置自动切换
            </p>

            <div className="flex items-center space-x-2">
              <RadioGroupItem value="sunrise-sunset" id="mode-sunrise" />
              <Label htmlFor="mode-sunrise" className="font-normal cursor-pointer">
                根据日出日落时间
              </Label>
            </div>
            <p className="text-sm text-muted-foreground ml-6">
              根据您所在位置的日出日落时间自动切换
            </p>
          </RadioGroup>
        </div>

        {/* 位置设置 - 仅在日出日落模式下显示 */}
        {autoSwitchMode === "sunrise-sunset" && (
          <div className="space-y-3 pt-4 border-t">
            <Label className="text-base font-semibold flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              位置设置
            </Label>

            {locationError && (
              <div className="p-3 bg-destructive/10 text-destructive rounded-md text-sm">
                {locationError}
              </div>
            )}

            {location && (
              <div className="p-3 bg-secondary/50 rounded-md text-sm">
                <p className="font-medium">当前位置</p>
                <p className="text-muted-foreground">
                  纬度: {location.latitude.toFixed(4)}° | 经度: {location.longitude.toFixed(4)}°
                </p>
              </div>
            )}

            <Button
              onClick={handleGetLocation}
              disabled={isLoadingLocation}
              variant="outline"
              className="w-full"
            >
              {isLoadingLocation ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  获取位置中...
                </>
              ) : (
                <>
                  <MapPin className="w-4 h-4 mr-2" />
                  使用当前位置
                </>
              )}
            </Button>

            <div className="space-y-2">
              <Label htmlFor="latitude" className="text-sm">
                或手动输入纬度
              </Label>
              <Input
                id="latitude"
                type="number"
                placeholder="例如: 39.9042"
                min="-90"
                max="90"
                step="0.0001"
                value={manualLatitude}
                onChange={(e) => setManualLatitude(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="longitude" className="text-sm">
                经度
              </Label>
              <Input
                id="longitude"
                type="number"
                placeholder="例如: 116.4074"
                min="-180"
                max="180"
                step="0.0001"
                value={manualLongitude}
                onChange={(e) => setManualLongitude(e.target.value)}
              />
            </div>

            <Button onClick={handleSaveManualLocation} className="w-full">
              保存位置
            </Button>

            <p className="text-xs text-muted-foreground">
              💡 提示：日出日落时间会每分钟检查一次，根据您的位置自动切换主题
            </p>
          </div>
        )}

        {/* 系统设置说明 */}
        {autoSwitchMode === "system" && (
          <div className="p-3 bg-secondary/50 rounded-md text-sm space-y-2">
            <p className="font-medium">系统主题设置</p>
            <p className="text-muted-foreground">
              您的主题将跟随系统设置自动切换。请在操作系统设置中调整深色模式偏好。
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
