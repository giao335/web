import { motion } from "framer-motion";
import { LogOut, User, LogIn, Settings } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";
import type { User as UserType } from "@shared/types";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ThemeSettings } from "./ThemeSettings";

interface UserMenuProps {
  user: UserType | null;
  loading: boolean;
  onLogout: () => void;
}

export function UserMenu({ user, loading, onLogout }: UserMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isThemeSettingsOpen, setIsThemeSettingsOpen] = useState(false);

  if (loading) {
    return (
      <div className="w-10 h-10 rounded-full bg-muted animate-pulse" />
    );
  }

  if (!user) {
    return (
      <motion.a
        href={getLoginUrl()}
        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-accent text-accent-foreground font-medium hover:bg-accent/90 transition-colors duration-200"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <LogIn className="w-4 h-4" />
        <span className="hidden sm:inline">登录</span>
      </motion.a>
    );
  }

  return (
    <div className="relative">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-muted transition-colors duration-200"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-accent-foreground font-semibold">
          {user.name?.[0]?.toUpperCase() || "U"}
        </div>
        <span className="hidden sm:inline text-sm font-medium text-foreground">
          {user.name || "用户"}
        </span>
      </motion.button>

      {isOpen && (
        <motion.div
          className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg z-50"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <div className="p-4 border-b border-border">
            <p className="text-sm font-medium text-foreground">{user.name}</p>
            <p className="text-xs text-muted-foreground">{user.email}</p>
          </div>

          <div className="p-2 space-y-1">
            <motion.a
              href="/profile"
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted transition-colors duration-200 text-sm text-foreground"
              whileHover={{ x: 4 }}
              onClick={() => setIsOpen(false)}
            >
              <User className="w-4 h-4" />
              个人资料
            </motion.a>
            <motion.button
              onClick={() => {
                setIsThemeSettingsOpen(true);
                setIsOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted transition-colors duration-200 text-sm text-foreground"
              whileHover={{ x: 4 }}
            >
              <Settings className="w-4 h-4" />
              主题设置
            </motion.button>
            <motion.button
              onClick={() => {
                onLogout();
                setIsOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted transition-colors duration-200 text-sm text-foreground"
              whileHover={{ x: 4 }}
            >
              <LogOut className="w-4 h-4" />
              退出登录
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* Theme Settings Dialog */}
      <Dialog open={isThemeSettingsOpen} onOpenChange={setIsThemeSettingsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>主题设置</DialogTitle>
          </DialogHeader>
          <ThemeSettings />
        </DialogContent>
      </Dialog>
    </div>
  );
}
