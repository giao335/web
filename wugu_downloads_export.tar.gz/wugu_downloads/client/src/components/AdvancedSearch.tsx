import React, { useState, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, Filter, ChevronDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { applicationsData } from "@shared/appData";

interface SearchFilters {
  query: string;
  category: string;
  appType: string;
  minRating: number;
}

interface AdvancedSearchProps {
  onSearch?: (results: typeof applicationsData) => void;
  onClose?: () => void;
}

export function AdvancedSearch({ onSearch, onClose }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    category: "all",
    appType: "all",
    minRating: 0,
  });

  const [showFilters, setShowFilters] = useState(false);

  // Get unique categories and app types
  const categories = useMemo(() => {
    const cats = new Set(applicationsData.map((app) => app.category));
    return Array.from(cats).sort();
  }, []);

  const appTypes = useMemo(() => {
    const types = new Set(applicationsData.map((app) => app.appType));
    return Array.from(types).sort();
  }, []);

  // Filter applications based on search criteria
  const searchResults = useMemo(() => {
    return applicationsData.filter((app) => {
      const matchesQuery =
        app.name.toLowerCase().includes(filters.query.toLowerCase()) ||
        app.description.toLowerCase().includes(filters.query.toLowerCase());

      const matchesCategory =
        filters.category === "all" || app.category === filters.category;

      const matchesAppType =
        filters.appType === "all" || app.appType === filters.appType;

      const matchesRating = app.rating >= filters.minRating;

      return (
        matchesQuery &&
        matchesCategory &&
        matchesAppType &&
        matchesRating
      );
    });
  }, [filters]);

  const handleSearch = useCallback(() => {
    if (onSearch) {
      onSearch(searchResults);
    }
  }, [searchResults, onSearch]);

  const handleReset = useCallback(() => {
    setFilters({
      query: "",
      category: "all",
      appType: "all",
      minRating: 0,
    });
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="w-full"
    >
      <Card className="p-4 space-y-4 bg-card border-border">
        {/* Main Search Input */}
        <div className="relative">
          <motion.div
            className="relative flex items-center"
            whileFocus={{ scale: 1.02 }}
          >
            <Search className="absolute left-3 w-5 h-5 text-muted-foreground pointer-events-none" />
            <Input
              type="text"
              placeholder="搜索应用名称或描述..."
              value={filters.query}
              onChange={(e) =>
                setFilters({ ...filters, query: e.target.value })
              }
              className="pl-10 pr-4 py-2 w-full"
            />
            {filters.query && (
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setFilters({ ...filters, query: "" })}
                className="absolute right-3 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </motion.button>
            )}
          </motion.div>
        </div>

        {/* Filter Toggle Button */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowFilters(!showFilters)}
          className="w-full flex items-center justify-between px-3 py-2 rounded-md border border-border hover:bg-accent/10 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <span className="text-sm font-medium">高级筛选</span>
          </div>
          <motion.div
            animate={{ rotate: showFilters ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown className="w-4 h-4" />
          </motion.div>
        </motion.button>

        {/* Filter Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="space-y-3 pt-3 border-t border-border"
            >
              {/* Category Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">平台分类</label>
                <Select value={filters.category} onValueChange={(value) =>
                  setFilters({ ...filters, category: value })
                }>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择平台" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部平台</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* App Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">应用类型</label>
                <Select value={filters.appType} onValueChange={(value) =>
                  setFilters({ ...filters, appType: value })
                }>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    {appTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Rating Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">最低评分</label>
                <Select value={filters.minRating.toString()} onValueChange={(value) =>
                  setFilters({ ...filters, minRating: parseFloat(value) })
                }>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择评分" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">全部评分</SelectItem>
                    <SelectItem value="3">3 星及以上</SelectItem>
                    <SelectItem value="3.5">3.5 星及以上</SelectItem>
                    <SelectItem value="4">4 星及以上</SelectItem>
                    <SelectItem value="4.5">4.5 星及以上</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Filter Actions */}
              <div className="flex gap-2 pt-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleReset}
                  className="flex-1 px-3 py-2 rounded-md border border-border hover:bg-accent/10 transition-colors text-sm font-medium"
                >
                  重置筛选
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowFilters(false)}
                  className="flex-1 px-3 py-2 rounded-md bg-accent text-accent-foreground hover:bg-accent/90 transition-colors text-sm font-medium"
                >
                  应用筛选
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Search Results Summary */}
        {filters.query || filters.category !== "all" || filters.appType !== "all" || filters.minRating > 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm text-muted-foreground"
          >
            找到 <span className="font-semibold text-foreground">{searchResults.length}</span> 个应用
          </motion.div>
        ) : null}
      </Card>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-4 space-y-2"
        >
          <div className="text-sm font-semibold text-foreground">搜索结果</div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
            <AnimatePresence>
              {searchResults.slice(0, 12).map((app, index) => (
                <motion.div
                  key={app.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.02, y: -2 }}
                  className="p-3 rounded-lg border border-border bg-card hover:border-accent/50 transition-all cursor-pointer"
                >
                  <div className="font-medium text-sm line-clamp-1">{app.name}</div>
                  <div className="text-xs text-muted-foreground line-clamp-1">
                    {app.description}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs bg-accent/10 text-accent px-2 py-1 rounded">
                      {app.appType}
                    </span>
                    <span className="text-xs font-semibold text-yellow-500">
                      ★ {app.rating}
                    </span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      )}

      {/* No Results */}
      {(filters.query || filters.category !== "all" || filters.appType !== "all" || filters.minRating > 0) &&
        searchResults.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 p-4 rounded-lg border border-border/50 bg-muted/50 text-center text-muted-foreground"
          >
            未找到匹配的应用，请尝试调整搜索条件
          </motion.div>
        )}
    </motion.div>
  );
}
