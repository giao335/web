import { motion } from "framer-motion";
import { Download, TrendingUp } from "lucide-react";
import type { Software } from "@shared/types";
import { useLocation } from "wouter";

interface RankingCardProps {
  software: Software;
  rank: number;
  onDownload?: (softwareId: number) => void;
}

export function RankingCard({ software, rank, onDownload }: RankingCardProps) {
  const [, navigate] = useLocation();
  const getRankColor = (rank: number) => {
    if (rank === 1) return "from-yellow-400 to-yellow-600";
    if (rank === 2) return "from-gray-300 to-gray-500";
    if (rank === 3) return "from-orange-400 to-orange-600";
    return "from-blue-400 to-blue-600";
  };

  const getMedalEmoji = (rank: number) => {
    if (rank === 1) return "🥇";
    if (rank === 2) return "🥈";
    if (rank === 3) return "🥉";
    return null;
  };

  return (
    <motion.div
      className="flex items-center gap-4 p-4 rounded-lg bg-card border border-border hover:border-accent/50 transition-all duration-300"
      whileHover={{ x: 4 }}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Rank Badge */}
      <motion.div
        className={`flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br ${getRankColor(rank)} flex items-center justify-center text-white font-bold text-lg`}
        whileHover={{ scale: 1.1 }}
      >
        {getMedalEmoji(rank) || `#${rank}`}
      </motion.div>

      {/* Software Info */}
      <motion.div
        className="flex-1 min-w-0 cursor-pointer"
        onClick={() => navigate(`/software/${software.id}`)}
        whileHover={{ opacity: 0.8 }}
      >
        <h3 className="font-semibold text-foreground truncate hover:text-accent transition-colors">{software.name}</h3>
        <p className="text-sm text-muted-foreground truncate">{software.description}</p>
        <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
          <span className="px-2 py-1 rounded bg-secondary text-secondary-foreground">
            {software.version}
          </span>
          <span>{software.fileSize}</span>
        </div>
      </motion.div>

      {/* Download Stats */}
      <div className="flex-shrink-0 text-right">
        <div className="flex items-center gap-1 justify-end text-accent font-semibold mb-2">
          <TrendingUp className="w-4 h-4" />
          <span>{(software.downloadCount || 0).toLocaleString()}</span>
        </div>
        <motion.button
          onClick={() => onDownload?.(software.id)}
          className="flex items-center gap-1 px-3 py-2 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 transition-colors duration-200 text-sm font-medium"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">下载</span>
        </motion.button>
      </div>
    </motion.div>
  );
}
