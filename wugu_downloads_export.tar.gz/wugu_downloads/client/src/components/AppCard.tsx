import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Download,
  Star,
  TrendingUp,
  ExternalLink,
  Heart,
} from "lucide-react";
import { cardHoverVariants } from "@/lib/animations";

interface AppCardProps {
  id: number;
  name: string;
  description: string;
  version: string;
  fileSize: string;
  rating: number;
  downloads: number;
  downloadUrl: string;
  category: string;
  appType: string;
  index?: number;
}

export function AppCard({
  id,
  name,
  description,
  version,
  fileSize,
  rating,
  downloads,
  downloadUrl,
  category,
  appType,
  index = 0,
}: AppCardProps) {
  const [isFavorited, setIsFavorited] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const downloadCountDisplay =
    downloads >= 1000000
      ? `${(downloads / 1000000).toFixed(1)}M`
      : downloads >= 1000
      ? `${(downloads / 1000).toFixed(1)}K`
      : downloads;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
      viewport={{ once: true }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      variants={cardHoverVariants}
      whileHover="hover"
      whileTap="tap"
    >
      <motion.div
        className="relative h-full p-4 rounded-lg border border-border bg-card hover:border-accent/50 transition-all overflow-hidden group"
        style={{
          background: isHovered
            ? "linear-gradient(135deg, var(--card) 0%, rgba(59, 130, 246, 0.05) 100%)"
            : "var(--card)",
        }}
      >
        {/* Background Gradient Animation */}
        <motion.div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          animate={isHovered ? { backgroundPosition: ["0% 0%", "100% 100%"] } : {}}
          transition={{ duration: 3, repeat: Infinity }}
          style={{
            background:
              "linear-gradient(45deg, transparent 30%, rgba(59, 130, 246, 0.1) 50%, transparent 70%)",
            backgroundSize: "200% 200%",
          }}
        />

        {/* Content */}
        <div className="relative z-10 space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <motion.h3
                className="font-semibold text-foreground line-clamp-1 text-sm md:text-base"
                animate={isHovered ? { x: 4 } : { x: 0 }}
                transition={{ duration: 0.2 }}
              >
                {name}
              </motion.h3>
              <p className="text-xs text-muted-foreground line-clamp-1">
                {description}
              </p>
            </div>

            {/* Favorite Button */}
            <motion.button
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsFavorited(!isFavorited)}
              className="flex-shrink-0 p-1.5 rounded-lg hover:bg-accent/10 transition-colors"
            >
              <motion.div
                animate={isFavorited ? { scale: [1, 1.3, 1] } : {}}
                transition={{ duration: 0.3 }}
              >
                <Heart
                  className={`w-4 h-4 transition-colors ${
                    isFavorited
                      ? "fill-red-500 text-red-500"
                      : "text-muted-foreground hover:text-red-500"
                  }`}
                />
              </motion.div>
            </motion.button>
          </div>

          {/* Version & Size */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground">
              v{version}
            </span>
            <span className="px-2 py-1 rounded-full bg-muted text-muted-foreground">
              {fileSize}
            </span>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-border/50">
            {/* Rating */}
            <motion.div
              className="text-center"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center justify-center gap-1 mb-1">
                <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                <span className="text-xs font-semibold text-foreground">
                  {rating}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">评分</p>
            </motion.div>

            {/* Downloads */}
            <motion.div
              className="text-center"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center justify-center gap-1 mb-1">
                <Download className="w-3 h-3 text-blue-500" />
                <span className="text-xs font-semibold text-foreground">
                  {downloadCountDisplay}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">下载</p>
            </motion.div>

            {/* Category */}
            <motion.div
              className="text-center"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center justify-center gap-1 mb-1">
                <TrendingUp className="w-3 h-3 text-green-500" />
                <span className="text-xs font-semibold text-foreground line-clamp-1">
                  {appType}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">类型</p>
            </motion.div>
          </div>

          {/* Download Button */}
          <motion.a
            href={downloadUrl}
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="block w-full mt-3 px-3 py-2 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 transition-colors font-medium text-sm text-center flex items-center justify-center gap-2 group/btn"
          >
            <Download className="w-4 h-4 group-hover/btn:animate-bounce" />
            <span>立即下载</span>
            <motion.div
              animate={isHovered ? { x: 4 } : { x: 0 }}
              transition={{ duration: 0.2 }}
            >
              <ExternalLink className="w-3 h-3" />
            </motion.div>
          </motion.a>

          {/* Hover Indicator */}
          <motion.div
            className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-accent to-accent/50"
            animate={isHovered ? { width: "100%" } : { width: "0%" }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
