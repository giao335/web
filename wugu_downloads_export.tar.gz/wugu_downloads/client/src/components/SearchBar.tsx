import { motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { useState } from "react";

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
}

export function SearchBar({ onSearch, placeholder = "搜索平台或软件..." }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    onSearch(value);
  };

  const handleClear = () => {
    setQuery("");
    onSearch("");
  };

  return (
    <motion.div
      className="w-full max-w-md mx-auto mb-8"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div
        className={`relative flex items-center px-4 py-3 rounded-lg border-2 transition-all duration-300 ${
          isFocused
            ? "border-accent bg-accent/5 shadow-lg shadow-accent/20"
            : "border-border bg-card hover:border-accent/50"
        }`}
      >
        <Search className="w-5 h-5 text-muted-foreground mr-3 flex-shrink-0" />
        
        <input
          type="text"
          value={query}
          onChange={handleChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          className="flex-1 bg-transparent outline-none text-foreground placeholder-muted-foreground"
        />

        {query && (
          <motion.button
            onClick={handleClear}
            className="p-1 hover:bg-muted rounded-md transition-colors duration-200"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <X className="w-4 h-4 text-muted-foreground hover:text-foreground transition-colors" />
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
