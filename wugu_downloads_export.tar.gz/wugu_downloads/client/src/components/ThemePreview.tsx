import React, { useState } from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface ThemePreviewProps {
  currentTheme: "light" | "dark";
  onThemeSelect: (theme: "light" | "dark") => void;
}

export function ThemePreview({ currentTheme, onThemeSelect }: ThemePreviewProps) {
  const [hoveredTheme, setHoveredTheme] = useState<"light" | "dark" | null>(null);

  const themes = [
    {
      id: "light",
      name: "浅色模式",
      bgColor: "#ffffff",
      textColor: "#1a1a1a",
      accentColor: "#2563EB",
      secondaryBg: "#f5f5f5",
      borderColor: "#e5e5e5",
    },
    {
      id: "dark",
      name: "深色模式",
      bgColor: "#1a1a1a",
      textColor: "#ffffff",
      accentColor: "#3b82f6",
      secondaryBg: "#2d2d2d",
      borderColor: "#404040",
    },
  ] as const;

  return (
    <div className="space-y-4">
      <div className="text-sm font-semibold text-foreground">主题预览</div>
      
      <div className="grid grid-cols-2 gap-4">
        {themes.map((theme) => {
          const isSelected = currentTheme === theme.id;
          const isHovered = hoveredTheme === theme.id;

          return (
            <div
              key={theme.id}
              className="relative"
              onMouseEnter={() => setHoveredTheme(theme.id)}
              onMouseLeave={() => setHoveredTheme(null)}
            >
              {/* Preview Card */}
              <div
                className="rounded-lg border-2 overflow-hidden transition-all duration-300 cursor-pointer"
                style={{
                  borderColor: isSelected ? theme.accentColor : theme.borderColor,
                  borderWidth: isSelected ? "2px" : "1px",
                  transform: isHovered ? "scale(1.02)" : "scale(1)",
                }}
                onClick={() => onThemeSelect(theme.id)}
              >
                {/* Preview Content */}
                <div
                  className="p-4 space-y-3"
                  style={{
                    backgroundColor: theme.bgColor,
                    minHeight: "200px",
                  }}
                >
                  {/* Header Preview */}
                  <div
                    className="h-8 rounded flex items-center px-3 gap-2"
                    style={{
                      backgroundColor: theme.secondaryBg,
                    }}
                  >
                    <div
                      className="w-4 h-4 rounded"
                      style={{
                        backgroundColor: theme.accentColor,
                      }}
                    />
                    <div
                      className="h-2 rounded flex-1"
                      style={{
                        backgroundColor: theme.borderColor,
                      }}
                    />
                  </div>

                  {/* Content Preview */}
                  <div className="space-y-2">
                    <div
                      className="h-3 rounded"
                      style={{
                        backgroundColor: theme.textColor,
                        opacity: 0.9,
                      }}
                    />
                    <div
                      className="h-2 rounded"
                      style={{
                        backgroundColor: theme.textColor,
                        opacity: 0.6,
                        width: "80%",
                      }}
                    />
                    <div
                      className="h-2 rounded"
                      style={{
                        backgroundColor: theme.textColor,
                        opacity: 0.6,
                        width: "70%",
                      }}
                    />
                  </div>

                  {/* Button Preview */}
                  <div className="pt-2 flex gap-2">
                    <div
                      className="h-6 rounded px-3 flex items-center text-xs font-medium"
                      style={{
                        backgroundColor: theme.accentColor,
                        color: "#ffffff",
                      }}
                    >
                      按钮
                    </div>
                    <div
                      className="h-6 rounded px-3 flex items-center text-xs"
                      style={{
                        backgroundColor: theme.secondaryBg,
                        color: theme.textColor,
                        opacity: 0.7,
                      }}
                    >
                      次要
                    </div>
                  </div>
                </div>

                {/* Theme Name */}
                <div
                  className="px-4 py-2 text-sm font-medium text-center"
                  style={{
                    backgroundColor: theme.secondaryBg,
                    color: theme.textColor,
                  }}
                >
                  {theme.name}
                </div>
              </div>

              {/* Selected Indicator */}
              {isSelected && (
                <div
                  className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center"
                  style={{
                    backgroundColor: theme.accentColor,
                  }}
                >
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <Button
          variant={currentTheme === "light" ? "default" : "outline"}
          size="sm"
          onClick={() => onThemeSelect("light")}
          className="w-full"
        >
          浅色
        </Button>
        <Button
          variant={currentTheme === "dark" ? "default" : "outline"}
          size="sm"
          onClick={() => onThemeSelect("dark")}
          className="w-full"
        >
          深色
        </Button>
      </div>
    </div>
  );
}
