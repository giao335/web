import { motion } from "framer-motion";
import { RankingCard } from "@/components/RankingCard";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, Trophy } from "lucide-react";
import { toast } from "sonner";

export default function Rankings() {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();

  // Fetch top software
  const { data: topSoftware, isLoading: isLoadingTop } = trpc.software.top.useQuery(
    { limit: 20 },
    { staleTime: 60000 } // Cache for 1 minute
  );

  // Fetch all categories
  const { data: categories, isLoading: isLoadingCategories } = trpc.software.categories.useQuery();

  // Fetch filtered software by category
  const { data: categorySoftware, isLoading: isLoadingCategory } = trpc.software.list.useQuery(
    { category: selectedCategory },
    { enabled: !!selectedCategory, staleTime: 60000 }
  );

  // Record download mutation
  const recordDownloadMutation = trpc.software.recordDownload.useMutation({
    onSuccess: () => {
      toast.success("下载已记录");
    },
    onError: () => {
      toast.error("记录下载失败");
    },
  });

  const handleDownload = (softwareId: number, downloadUrl: string) => {
    // Record the download
    recordDownloadMutation.mutate({ softwareId });
    // Open download link
    window.open(downloadUrl, "_blank");
  };

  const displayData = selectedCategory ? categorySoftware : topSoftware;
  const isLoading = selectedCategory ? isLoadingCategory : isLoadingTop;

  return (
    <div className="min-h-screen bg-background pt-20">
      {/* Header */}
      <motion.section
        className="py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-accent/10 to-background"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="w-8 h-8 text-accent" />
            <h1 className="text-4xl font-bold text-foreground">下载排行榜</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            发现最受欢迎的软件和应用，查看实时下载排行
          </p>
        </div>
      </motion.section>

      {/* Category Filter */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 border-b border-border">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-sm font-semibold text-foreground mb-4">按分类筛选</h2>
          <div className="flex flex-wrap gap-2">
            <motion.button
              onClick={() => setSelectedCategory(undefined)}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                !selectedCategory
                  ? "bg-accent text-accent-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              全部
            </motion.button>

            {isLoadingCategories ? (
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            ) : (
              categories?.map((category) => (
                <motion.button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.name)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    selectedCategory === category.name
                      ? "bg-accent text-accent-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category.name}
                </motion.button>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Rankings List */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
            </div>
          ) : displayData && displayData.length > 0 ? (
            <motion.div
              className="space-y-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
            >
              {displayData.map((software, index) => (
                <RankingCard
                  key={software.id}
                  software={software}
                  rank={index + 1}
                  onDownload={(softwareId) =>
                    handleDownload(softwareId, software.downloadUrl)
                  }
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              className="text-center py-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
            >
              <p className="text-lg text-muted-foreground">
                {selectedCategory
                  ? `暂无 ${selectedCategory} 分类的软件`
                  : "暂无下载排行数据"}
              </p>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
}
