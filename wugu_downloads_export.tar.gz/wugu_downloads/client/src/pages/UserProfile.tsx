import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Download, Heart, Settings, LogOut } from "lucide-react";
import { Header } from "@/components/Header";
import { useTheme } from "@/contexts/ThemeContext";
import { useState } from "react";
import { toast } from "sonner";

export default function UserProfile() {
  const { user, loading, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch user data
  const downloadHistoryQuery = trpc.user.downloadHistory.useQuery(
    { limit: 10, offset: 0 },
    { enabled: !!user }
  );
  const favoritesQuery = trpc.user.favorites.useQuery(
    { limit: 10, offset: 0 },
    { enabled: !!user }
  );
  const preferencesQuery = trpc.user.getPreferences.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Mutations
  const updatePreferencesMutation = trpc.user.updatePreferences.useMutation({
    onSuccess: () => {
      toast.success("设置已保存");
      preferencesQuery.refetch();
    },
    onError: () => {
      toast.error("保存设置失败");
    },
  });

  const removeFavoriteMutation = trpc.user.removeFavorite.useMutation({
    onSuccess: () => {
      toast.success("已从收藏中移除");
      favoritesQuery.refetch();
    },
    onError: () => {
      toast.error("移除收藏失败");
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={null} loading={true} onLogout={() => {}} onSearch={() => {}} />
        <div className="container mx-auto max-w-6xl px-4 py-12">
          <div className="text-center">加载中...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={null} loading={false} onLogout={() => {}} onSearch={() => {}} />
        <div className="container mx-auto max-w-6xl px-4 py-12">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">请先登录以查看个人资料</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} loading={false} onLogout={logout} onSearch={setSearchQuery} />

      <div className="container mx-auto max-w-6xl px-4 py-12">
        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">{user.name || "用户"}</CardTitle>
                  <CardDescription>{user.email}</CardDescription>
                </div>
                <Button variant="outline" onClick={logout} className="gap-2">
                  <LogOut className="w-4 h-4" />
                  退出登录
                </Button>
              </div>
            </CardHeader>
          </Card>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Tabs defaultValue="history" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="history" className="gap-2">
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">下载历史</span>
              </TabsTrigger>
              <TabsTrigger value="favorites" className="gap-2">
                <Heart className="w-4 h-4" />
                <span className="hidden sm:inline">收藏</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2">
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">设置</span>
              </TabsTrigger>
            </TabsList>

            {/* Download History Tab */}
            <TabsContent value="history" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>下载历史</CardTitle>
                  <CardDescription>您最近下载的应用</CardDescription>
                </CardHeader>
                <CardContent>
                  {downloadHistoryQuery.isLoading ? (
                    <div className="text-center text-muted-foreground">加载中...</div>
                  ) : downloadHistoryQuery.data && downloadHistoryQuery.data.length > 0 ? (
                    <div className="space-y-4">
                      {downloadHistoryQuery.data.map((item) => (
                        <motion.div
                          key={item.id}
                          className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-secondary/50 transition-colors"
                          whileHover={{ x: 4 }}
                        >
                          <div>
                            <h3 className="font-medium">{item.software.name}</h3>
                            <p className="text-sm text-muted-foreground">
                              {item.software.description}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              下载于: {new Date(item.downloadedAt).toLocaleDateString('zh-CN')}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{item.software.version}</p>
                            <p className="text-xs text-muted-foreground">
                              {item.software.fileSize ? ((Number(item.software.fileSize)) / 1024 / 1024).toFixed(2) : 'N/A'} MB
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      暂无下载历史
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Favorites Tab */}
            <TabsContent value="favorites" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>我的收藏</CardTitle>
                  <CardDescription>您收藏的应用</CardDescription>
                </CardHeader>
                <CardContent>
                  {favoritesQuery.isLoading ? (
                    <div className="text-center text-muted-foreground">加载中...</div>
                  ) : favoritesQuery.data && favoritesQuery.data.length > 0 ? (
                    <div className="space-y-4">
                      {favoritesQuery.data.map((item) => (
                        <motion.div
                          key={item.id}
                          className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-secondary/50 transition-colors"
                          whileHover={{ x: 4 }}
                        >
                          <div>
                            <h3 className="font-medium">{item.software.name}</h3>
                            <p className="text-sm text-muted-foreground">
                              {item.software.description}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              下载次数: {item.software.downloadCount}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (removeFavoriteMutation.mutate) {
                                removeFavoriteMutation.mutate({ softwareId: item.softwareId });
                              }
                            }}
                            disabled={removeFavoriteMutation.isPending}
                          >
                            移除
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      暂无收藏
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>设置</CardTitle>
                  <CardDescription>管理您的偏好设置</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Theme Setting */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">主题</h3>
                      <p className="text-sm text-muted-foreground">
                        当前: {theme === 'light' ? '浅色模式' : '深色模式'}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (toggleTheme) {
                          toggleTheme();
                        }
                        if (updatePreferencesMutation.mutate) {
                          updatePreferencesMutation.mutate({
                            theme: theme === 'light' ? 'dark' : 'light',
                          });
                        }
                      }}
                    >
                      切换主题
                    </Button>
                  </div>

                  {/* Language Setting */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">语言</h3>
                      <p className="text-sm text-muted-foreground">
                        当前: 简体中文
                      </p>
                    </div>
                    <Button variant="outline" size="sm" disabled>
                      暂不支持
                    </Button>
                  </div>

                  {/* Notifications Setting */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h3 className="font-medium">通知</h3>
                      <p className="text-sm text-muted-foreground">
                        接收应用更新通知
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (preferencesQuery.data) {
                          const enabled = preferencesQuery.data.notificationsEnabled === 1;
                          updatePreferencesMutation.mutate({
                            notificationsEnabled: !enabled,
                          });
                        }
                      }}
                      disabled={updatePreferencesMutation.isPending}
                    >
                      {preferencesQuery.data && preferencesQuery.data.notificationsEnabled === 1 ? '已启用' : '已禁用'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
