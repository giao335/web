import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { motion } from "framer-motion";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, Download, ArrowLeft, MessageSquare, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function SoftwareDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user, logout, loading } = useAuth();
  const softwareId = parseInt(id || "0", 10);

  // Fetch software details
  const { data: software, isLoading: softwareLoading } = trpc.software.getById.useQuery(
    { id: softwareId },
    { enabled: softwareId > 0 }
  );

  // Fetch reviews
  const { data: reviews = [] } = trpc.details.getReviews.useQuery(
    { softwareId },
    { enabled: softwareId > 0 }
  );

  // Fetch rating info
  const { data: ratingInfo } = trpc.details.getAverageRating.useQuery(
    { softwareId },
    { enabled: softwareId > 0 }
  );

  // Fetch changelogs
  const { data: changelogs = [] } = trpc.details.getChangelogs.useQuery(
    { softwareId },
    { enabled: softwareId > 0 }
  );

  // Mutations
  const recordDownloadMutation = trpc.software.recordDownload.useMutation();
  const addReviewMutation = trpc.details.addReview.useMutation();

  const [rating, setRating] = useState(0);
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewComment, setReviewComment] = useState("");

  const handleDownload = () => {
    if (software?.downloadUrl) {
      recordDownloadMutation.mutate({ softwareId });
      window.open(software.downloadUrl, "_blank");
      toast.success("下载开始！");
    }
  };

  const handleSubmitReview = async () => {
    if (!user) {
      toast.error("请先登录");
      return;
    }

    if (rating === 0) {
      toast.error("请选择评分");
      return;
    }

    try {
      await addReviewMutation.mutateAsync({
        softwareId,
        rating,
        title: reviewTitle,
        comment: reviewComment,
      });
      toast.success("评论已提交");
      setRating(0);
      setReviewTitle("");
      setReviewComment("");
    } catch (error) {
      toast.error("提交评论失败");
    }
  };

  const handleSearch = () => {
    // Search functionality can be implemented here
  };

  if (softwareLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} loading={loading} onLogout={logout} onSearch={handleSearch} />
        <div className="flex items-center justify-center h-96">
          <div className="text-muted-foreground">加载中...</div>
        </div>
      </div>
    );
  }

  if (!software) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} loading={loading} onLogout={logout} onSearch={handleSearch} />
        <div className="flex items-center justify-center h-96">
          <div className="text-muted-foreground">软件不存在</div>
        </div>
      </div>
    );
  }

  const average = ratingInfo?.average || 0;
  const distribution = ratingInfo?.distribution || { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  const totalReviews = reviews.length;

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} loading={loading} onLogout={logout} onSearch={handleSearch} />

      <main className="container mx-auto max-w-4xl px-4 py-8">
        {/* Back button */}
        <motion.button
          onClick={() => navigate("/rankings")}
          className="flex items-center gap-2 text-accent hover:text-accent/80 mb-6 transition-colors"
          whileHover={{ x: -4 }}
        >
          <ArrowLeft className="w-4 h-4" />
          返回排行榜
        </motion.button>

        {/* Software Header */}
        <motion.div
          className="bg-card border border-border rounded-lg p-8 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex gap-6 mb-6">
            <div className="w-24 h-24 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-4xl font-bold text-accent">
                {software.name.charAt(0)}
              </span>
            </div>

            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">
                {software.name}
              </h1>
              <p className="text-muted-foreground mb-4">{software.description}</p>

              <div className="flex items-center gap-6 mb-4">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(average)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="font-semibold">{average.toFixed(1)}</span>
                  <span className="text-muted-foreground">({totalReviews} 评论)</span>
                </div>

                <div className="flex items-center gap-2 text-muted-foreground">
                  <Download className="w-4 h-4" />
                  <span>{software.downloadCount.toLocaleString()} 下载</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleDownload}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  <Download className="w-4 h-4 mr-2" />
                  立即下载
                </Button>
                <Button variant="outline">
                  <span className="text-sm">{software.fileSize}</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Software Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-border">
            <div>
              <div className="text-xs text-muted-foreground mb-1">版本</div>
              <div className="font-semibold">{software.version}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">分类</div>
              <div className="font-semibold">{software.category}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">文件大小</div>
              <div className="font-semibold">{software.fileSize}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">下载次数</div>
              <div className="font-semibold">{software.downloadCount}</div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <Tabs defaultValue="reviews" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">
              <MessageSquare className="w-4 h-4 mr-2" />
              评论 ({totalReviews})
            </TabsTrigger>
            <TabsTrigger value="changelog">
              <Zap className="w-4 h-4 mr-2" />
              更新日志
            </TabsTrigger>
            <TabsTrigger value="details">详细信息</TabsTrigger>
          </TabsList>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-6 mt-6">
            {/* Rating Distribution */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">评分分布</h3>
              <div className="space-y-3">
                {[5, 4, 3, 2, 1].map((star) => (
                  <div key={star} className="flex items-center gap-3">
                    <span className="w-12 text-sm">{star} 星</span>
                    <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-accent"
                        style={{
                          width: `${
                            totalReviews > 0
                              ? (distribution[star as keyof typeof distribution] /
                                  totalReviews) *
                                100
                              : 0
                          }%`,
                        }}
                      />
                    </div>
                    <span className="w-12 text-right text-sm text-muted-foreground">
                      {distribution[star as keyof typeof distribution]}
                    </span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Add Review Form */}
            {user ? (
              <Card className="p-6">
                <h3 className="font-semibold mb-4">发表评论</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">评分</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRating(star)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              star <= rating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">标题</label>
                    <input
                      type="text"
                      value={reviewTitle}
                      onChange={(e) => setReviewTitle(e.target.value)}
                      placeholder="评论标题"
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">评论</label>
                    <textarea
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="分享您的使用体验..."
                      rows={4}
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                    />
                  </div>

                  <Button
                    onClick={handleSubmitReview}
                    disabled={addReviewMutation.isPending}
                    className="w-full"
                  >
                    {addReviewMutation.isPending ? "提交中..." : "提交评论"}
                  </Button>
                </div>
              </Card>
            ) : (
              <Card className="p-6 text-center">
                <p className="text-muted-foreground mb-4">请登录后发表评论</p>
              </Card>
            )}

            {/* Reviews List */}
            <div className="space-y-4">
              {reviews.length > 0 ? (
                reviews.map((review) => (
                  <motion.div
                    key={review.id}
                    className="bg-card border border-border rounded-lg p-6"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex gap-2 items-center mb-1">
                          <div className="flex gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < review.rating
                                    ? "fill-yellow-400 text-yellow-400"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {new Date(review.createdAt).toLocaleDateString("zh-CN")}
                          </span>
                        </div>
                        {review.title && (
                          <h4 className="font-semibold text-foreground">
                            {review.title}
                          </h4>
                        )}
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-muted-foreground text-sm">{review.comment}</p>
                    )}
                  </motion.div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  暂无评论，成为第一个评论者吧！
                </div>
              )}
            </div>
          </TabsContent>

          {/* Changelog Tab */}
          <TabsContent value="changelog" className="space-y-4 mt-6">
            {changelogs.length > 0 ? (
              changelogs.map((changelog) => (
                <motion.div
                  key={changelog.id}
                  className="bg-card border border-border rounded-lg p-6"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-foreground">
                          v{changelog.version}
                        </h3>
                        <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">
                          {new Date(changelog.releaseDate).toLocaleDateString("zh-CN")}
                        </span>
                      </div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">
                        {changelog.title}
                      </h4>

                      {changelog.description && (
                        <p className="text-sm text-muted-foreground mb-3">
                          {changelog.description}
                        </p>
                      )}

                      {changelog.features && (
                        <div className="mb-3">
                          <h5 className="text-xs font-semibold text-foreground mb-2">
                            新增功能：
                          </h5>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            {JSON.parse(changelog.features).map(
                              (feature: string, idx: number) => (
                                <li key={idx} className="flex gap-2">
                                  <span>•</span>
                                  <span>{feature}</span>
                                </li>
                              )
                            )}
                          </ul>
                        </div>
                      )}

                      {changelog.bugFixes && (
                        <div>
                          <h5 className="text-xs font-semibold text-foreground mb-2">
                            问题修复：
                          </h5>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            {JSON.parse(changelog.bugFixes).map(
                              (fix: string, idx: number) => (
                                <li key={idx} className="flex gap-2">
                                  <span>•</span>
                                  <span>{fix}</span>
                                </li>
                              )
                            )}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                暂无更新日志
              </div>
            )}
          </TabsContent>

          {/* Details Tab */}
          <TabsContent value="details" className="mt-6">
            <Card className="p-6">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-foreground mb-2">软件名称</h4>
                  <p className="text-muted-foreground">{software.name}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-2">描述</h4>
                  <p className="text-muted-foreground">{software.description}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">版本</h4>
                    <p className="text-muted-foreground">{software.version}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">分类</h4>
                    <p className="text-muted-foreground">{software.category}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">文件大小</h4>
                    <p className="text-muted-foreground">{software.fileSize}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">下载次数</h4>
                    <p className="text-muted-foreground">
                      {software.downloadCount.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
