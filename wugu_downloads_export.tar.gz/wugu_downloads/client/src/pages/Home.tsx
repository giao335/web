import { Header } from "@/components/Header";
import { AdvancedSearch } from "@/components/AdvancedSearch";
import { PopularWebsites } from "@/components/PopularWebsites";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";
import {
  Download,
  Star,
  ChevronRight,
  Sparkles,
  Gamepad2,
  Briefcase,
  MessageSquare,
  Code,
  Film,
  Wrench,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { WelcomeDialog } from "@/components/WelcomeDialog";

/**
 * Home Page - 五谷杂粮下载中心
 * 
 * Design Philosophy: Modern Minimalism
 * - Clean, professional layout with ample whitespace
 * - Integrated search, categories, and popular websites
 * - Blue accent color (#2563EB) for CTAs
 * - Smooth animations and transitions (200-300ms)
 * - Typography: Poppins for headings, Inter for body text
 * - Rich Framer Motion animations for enhanced interactivity
 */

const APP_CATEGORIES = [
  {
    id: "game",
    name: "游戏",
    icon: <Gamepad2 className="w-6 h-6" />,
    color: "#FF6B6B",
    description: "热门游戏和娱乐应用",
  },
  {
    id: "productivity",
    name: "生产力",
    icon: <Briefcase className="w-6 h-6" />,
    color: "#4ECDC4",
    description: "办公和效率工具",
  },
  {
    id: "social",
    name: "社交",
    icon: <MessageSquare className="w-6 h-6" />,
    color: "#45B7D1",
    description: "社交通讯应用",
  },
  {
    id: "development",
    name: "开发",
    icon: <Code className="w-6 h-6" />,
    color: "#96CEB4",
    description: "开发工具和框架",
  },
  {
    id: "media",
    name: "媒体",
    icon: <Film className="w-6 h-6" />,
    color: "#FFEAA7",
    description: "音视频编辑工具",
  },
  {
    id: "utility",
    name: "工具",
    icon: <Wrench className="w-6 h-6" />,
    color: "#DDA15E",
    description: "系统和实用工具",
  },
];

export default function Home() {
  const { user, loading, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <WelcomeDialog />
      <Header 
        user={user} 
        loading={loading} 
        onLogout={logout} 
        onSearch={setSearchQuery}
      />

      {/* Hero Section - Clean and Minimal */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background via-background to-secondary/10">
        <motion.div
          className="container mx-auto max-w-5xl"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Main Heading */}
          <div className="text-center mb-12">
            <motion.div
              className="flex items-center justify-center gap-2 mb-4"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Sparkles className="w-6 h-6 text-accent" />
              <span className="text-sm font-semibold text-accent uppercase tracking-wider">
                发现应用
              </span>
            </motion.div>

            <motion.h1
              className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1, type: "spring", stiffness: 100 }}
            >
              五谷杂粮
            </motion.h1>

            <motion.p
              className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              发现和下载最受欢迎的软件应用。支持 Windows、Linux、macOS、Android、iOS 等多个平台。
            </motion.p>

            {/* Feature highlights */}
            <motion.div
              className="flex flex-wrap justify-center gap-6 mt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Download className="w-4 h-4 text-accent" />
                <span>60+ 应用</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Star className="w-4 h-4 text-accent" />
                <span>用户评分</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <ChevronRight className="w-4 h-4 text-accent" />
                <span>快速下载</span>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Divider */}
      <div className="h-1 bg-gradient-to-r from-transparent via-border to-transparent" />

      {/* Advanced Search Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-background">
        <div className="container mx-auto max-w-6xl">
          <AdvancedSearch />
        </div>
      </section>

      {/* Divider */}
      <div className="h-1 bg-gradient-to-r from-transparent via-border to-transparent" />

      {/* Software Categories Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
        <div className="container mx-auto max-w-6xl">
          {/* Section Header */}
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              浏览软件分类
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              选择您感兴趣的分类，发现最受欢迎的应用和软件
            </p>
          </motion.div>

          {/* Category Grid */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ staggerChildren: 0.1, delayChildren: 0.2 }}
            viewport={{ once: true }}
          >
            {APP_CATEGORIES.map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <motion.div
                  whileHover={{ scale: 1.02, y: -8 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() =>
                    setSelectedCategory(
                      selectedCategory === category.id ? null : category.id
                    )
                  }
                >
                  <Card
                    className="p-6 cursor-pointer transition-all duration-300 hover:shadow-lg border-2 hover:border-accent"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div
                        className="p-3 rounded-lg"
                        style={{ backgroundColor: `${category.color}20` }}
                      >
                        <div style={{ color: category.color }}>
                          {category.icon}
                        </div>
                      </div>
                      <motion.div
                        animate={selectedCategory === category.id ? { rotate: 90 } : { rotate: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      </motion.div>
                    </div>

                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {category.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {category.description}
                    </p>

                    {/* Hover Indicator */}
                    <motion.div
                      className="mt-4 h-1 bg-gradient-to-r from-transparent via-accent to-transparent rounded-full"
                      animate={selectedCategory === category.id ? { opacity: 1 } : { opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    />
                  </Card>
                </motion.div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Divider */}
      <div className="h-1 bg-gradient-to-r from-transparent via-border to-transparent" />

      {/* Popular Websites Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-secondary/5">
        <div className="container mx-auto max-w-6xl">
          <PopularWebsites limit={6} />
        </div>
      </section>

      {/* Divider */}
      <div className="h-1 bg-gradient-to-r from-transparent via-border to-transparent" />

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
        <motion.div
          className="container mx-auto max-w-4xl text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            准备好开始了吗？
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            使用搜索功能快速找到您需要的应用，浏览分类发现更多软件，或查看热门网站资源。
          </p>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-3 rounded-lg bg-accent text-accent-foreground hover:bg-accent/90 transition-colors font-semibold flex items-center gap-2 mx-auto"
          >
            <Download className="w-5 h-5" />
            立即开始浏览
          </motion.button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-foreground/5 border-t border-border">
        <motion.div
          className="container mx-auto max-w-6xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Brand */}
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                五谷杂粮
              </h3>
              <p className="text-sm text-muted-foreground">
                您的多平台软件下载中心
              </p>
            </div>

            {/* Links */}
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-4">
                快速链接
              </h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    关于我们
                  </motion.a>
                </li>
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    隐私政策
                  </motion.a>
                </li>
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    联系我们
                  </motion.a>
                </li>
              </ul>
            </div>

            {/* Social */}
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-4">
                关注我们
              </h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    GitHub
                  </motion.a>
                </li>
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    Twitter
                  </motion.a>
                </li>
                <li>
                  <motion.a
                    href="#"
                    className="text-muted-foreground hover:text-accent transition-colors"
                    whileHover={{ x: 4 }}
                  >
                    Discord
                  </motion.a>
                </li>
              </ul>
            </div>
          </div>

          {/* Copyright */}
          <motion.div
            className="pt-8 border-t border-border text-center text-sm text-muted-foreground"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <p>
              © 2026 五谷杂粮. All rights reserved. | Made with{" "}
              <span className="text-accent">❤</span> by Manus
            </p>
          </motion.div>
        </motion.div>
      </footer>
    </div>
  );
}
