import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { calculateSunTimes, isDaytime, getSavedLocation, saveLocation } from "@/lib/sunriseSunset";

type Theme = "light" | "dark";
type AutoSwitchMode = "off" | "system" | "sunrise-sunset";

interface ThemeContextType {
  theme: Theme;
  toggleTheme?: () => void;
  switchable: boolean;
  isTransitioning?: boolean;
  autoSwitchMode: AutoSwitchMode;
  setAutoSwitchMode: (mode: AutoSwitchMode) => void;
  location: { latitude: number; longitude: number } | null;
  setLocation: (location: { latitude: number; longitude: number }) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  switchable?: boolean;
}

export function ThemeProvider({
  children,
  defaultTheme = "light",
  switchable = false,
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(() => {
    if (switchable) {
      const stored = localStorage.getItem("theme");
      return (stored as Theme) || defaultTheme;
    }
    return defaultTheme;
  });

  const [isTransitioning, setIsTransitioning] = useState(false);

  // 自动切换相关状态
  const [autoSwitchMode, setAutoSwitchModeState] = useState<AutoSwitchMode>(() => {
    if (switchable) {
      const stored = localStorage.getItem("themeAutoSwitchMode");
      return (stored as AutoSwitchMode) || "off";
    }
    return "off";
  });

  const [location, setLocationState] = useState<{ latitude: number; longitude: number } | null>(
    () => {
      const saved = getSavedLocation();
      return saved;
    }
  );

  // 应用主题到 DOM
  useEffect(() => {
    const root = document.documentElement;

    // Start transition state
    setIsTransitioning(true);

    // Disable transitions during theme change to avoid flash
    root.classList.add("no-transition");

    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }

    // Re-enable transitions after a brief delay to allow smooth animation
    const timer = setTimeout(() => {
      root.classList.remove("no-transition");
      setIsTransitioning(false);
    }, 50);

    if (switchable) {
      localStorage.setItem("theme", theme);
    }

    return () => clearTimeout(timer);
  }, [theme, switchable]);

  // 处理系统主题变化
  useEffect(() => {
    if (!switchable || autoSwitchMode !== "system") return;

    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

    const handleChange = (e: MediaQueryListEvent) => {
      setTheme(e.matches ? "dark" : "light");
    };

    // 初始设置
    setTheme(mediaQuery.matches ? "dark" : "light");

    // 监听系统主题变化
    mediaQuery.addEventListener("change", handleChange);

    return () => {
      mediaQuery.removeEventListener("change", handleChange);
    };
  }, [switchable, autoSwitchMode]);

  // 处理日出日落自动切换
  useEffect(() => {
    if (!switchable || autoSwitchMode !== "sunrise-sunset" || !location) return;

    const updateThemeBasedOnSunTimes = () => {
      const sunTimes = calculateSunTimes(new Date(), location.latitude, location.longitude);
      const isDay = isDaytime(sunTimes);
      setTheme(isDay ? "light" : "dark");
    };

    // 初始更新
    updateThemeBasedOnSunTimes();

    // 每分钟检查一次
    const interval = setInterval(updateThemeBasedOnSunTimes, 60000);

    return () => clearInterval(interval);
  }, [switchable, autoSwitchMode, location]);

  const toggleTheme = switchable
    ? () => {
        // 手动切换时禁用自动模式
        if (autoSwitchMode !== "off") {
          setAutoSwitchModeState("off");
          localStorage.setItem("themeAutoSwitchMode", "off");
        }
        setTheme((prev) => (prev === "light" ? "dark" : "light"));
      }
    : undefined;

  const setAutoSwitchMode = useCallback(
    (mode: AutoSwitchMode) => {
      if (!switchable) return;
      setAutoSwitchModeState(mode);
      localStorage.setItem("themeAutoSwitchMode", mode);
    },
    [switchable]
  );

  const setLocation = useCallback(
    (newLocation: { latitude: number; longitude: number }) => {
      setLocationState(newLocation);
      saveLocation(newLocation.latitude, newLocation.longitude);
    },
    []
  );

  return (
    <ThemeContext.Provider
      value={{
        theme,
        toggleTheme,
        switchable,
        isTransitioning,
        autoSwitchMode,
        setAutoSwitchMode,
        location,
        setLocation,
      }}
    >
      {/* Add transition overlay for smooth theme switching */}
      {isTransitioning && switchable && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            pointerEvents: "none",
            zIndex: 9999,
            opacity: 0,
            animation: "fadeInOut 0.35s ease-in-out",
          }}
        />
      )}
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within ThemeProvider");
  }
  return context;
}
